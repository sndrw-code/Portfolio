<?php
session_start();
include "db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "head_admin") {
    echo "Access denied.";
    exit();
}

$full_name = trim($_POST["full_name"] ?? "");
$age = trim($_POST["age"] ?? "");
$username = trim($_POST["username"] ?? "");
$password = trim($_POST["password"] ?? "");
$role = "admin";

if (empty($full_name) || empty($age) || empty($username) || empty($password)) {
    echo "Please complete all fields.";
    exit();
}

$check = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
$check->bind_param("s", $username);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    echo "Username already exists.";
    exit();
}

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO users (full_name, age, username, password, role) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sisss", $full_name, $age, $username, $hashed_password, $role);

if ($stmt->execute()) {
    echo "Admin account created successfully. <a href='admin.php'>Go back</a>";
} else {
    echo "Failed to create admin.";
}

$stmt->close();
$conn->close();
?>