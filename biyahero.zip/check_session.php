<?php
session_start();

header("Content-Type: application/json");

if (isset($_SESSION["user_id"])) {
    $full_name = $_SESSION["full_name"] ?? $_SESSION["username"] ?? "User";
    $name_parts = explode(" ", trim($full_name));
    $first_name = $name_parts[0] ?? "User";
    $role = $_SESSION["role"] ?? "commuter";

    echo json_encode([
        "status" => "logged_in",
        "user_id" => $_SESSION["user_id"],
        "full_name" => $full_name,
        "first_name" => $first_name,
        "role" => $role,
        "is_admin" => ($role === "admin" || $role === "head_admin"),
        "is_head_admin" => ($role === "head_admin")
    ]);
} else {
    echo json_encode([
        "status" => "not_logged_in"
    ]);
    exit();
}
?>
