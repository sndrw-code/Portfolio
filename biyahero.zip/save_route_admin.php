<?php
session_start();
include "db.php";


function ensureRouteColumn($conn, $column, $definition) {
    $safe_column = $conn->real_escape_string($column);
    $result = $conn->query("SHOW COLUMNS FROM routes LIKE '$safe_column'");

    if ($result && $result->num_rows === 0) {
        $conn->query("ALTER TABLE routes ADD COLUMN $column $definition");
    }
}

function ensureRouteSchema($conn) {
    ensureRouteColumn($conn, "direction", "varchar(50) DEFAULT NULL");
    ensureRouteColumn($conn, "transfers", "int(11) NOT NULL DEFAULT 0");
    ensureRouteColumn($conn, "badge", "varchar(50) DEFAULT 'badge-teal'");
    ensureRouteColumn($conn, "stops", "text");
    ensureRouteColumn($conn, "landmarks", "text");
    ensureRouteColumn($conn, "reason", "text");
    ensureRouteColumn($conn, "walking", "text");
    ensureRouteColumn($conn, "instructions", "text");
    ensureRouteColumn($conn, "notes", "text");
}

ensureRouteSchema($conn);

$is_ajax = isset($_POST["ajax"]) || strtolower($_SERVER["HTTP_X_REQUESTED_WITH"] ?? "") === "xmlhttprequest";

function respondAdminSave($status, $message, $route_id = null) {
    global $is_ajax;

    if ($is_ajax) {
        header("Content-Type: application/json");
        echo json_encode([
            "status" => $status,
            "message" => $message,
            "route_id" => $route_id
        ]);
    } else {
        if ($status === "success") {
            header("Location: admin.php");
        } else {
            echo $message;
        }
    }

    exit();
}

if (!isset($_SESSION["user_id"])) {
    respondAdminSave("error", "User not logged in");
}

if ($_SESSION["role"] !== "admin" && $_SESSION["role"] !== "head_admin") {
    respondAdminSave("error", "Access denied");
}

$route_id_raw = trim($_POST["route_id"] ?? $_POST["id"] ?? "");
$route_id = ctype_digit($route_id_raw) ? intval($route_id_raw) : 0;

$route_name = trim($_POST["route_name"] ?? $_POST["name"] ?? "");
$category = trim($_POST["category"] ?? "");
$transport = trim($_POST["transport"] ?? "");
$operator = trim($_POST["operator"] ?? $_POST["company"] ?? "");
$origin = trim($_POST["origin"] ?? "");
$destination = trim($_POST["destination"] ?? "");
$fare = trim($_POST["fare"] ?? "");
$travel_time = trim($_POST["travel_time"] ?? $_POST["time"] ?? "");
$distance = trim($_POST["distance"] ?? "");
$schedule = trim($_POST["schedule"] ?? "");
$tag = trim($_POST["tag"] ?? "Available");
$status = trim($_POST["status"] ?? "active");
$direction = trim($_POST["direction"] ?? "");
$transfers = intval($_POST["transfers"] ?? 0);
$badge = trim($_POST["badge"] ?? "badge-teal");
$stops = trim($_POST["stops"] ?? "");
$landmarks = trim($_POST["landmarks"] ?? "");
$reason = trim($_POST["reason"] ?? "");
$walking = trim($_POST["walking"] ?? "");
$instructions = trim($_POST["instructions"] ?? "");
$notes = trim($_POST["notes"] ?? "");

if ($status !== "active" && $status !== "inactive") {
    $status = "active";
}

if ($route_name === "" || $category === "" || $transport === "" || $origin === "" || $destination === "" || $fare === "" || $travel_time === "") {
    respondAdminSave("error", "Please complete all required fields.");
}

$fare_value = floatval($fare);

if ($route_id > 0) {
    $stmt = $conn->prepare("
        UPDATE routes
        SET route_name = ?, category = ?, transport = ?, operator = ?, origin = ?, destination = ?, fare = ?, travel_time = ?, distance = ?, schedule = ?, tag = ?, status = ?, direction = ?, transfers = ?, badge = ?, stops = ?, landmarks = ?, reason = ?, walking = ?, instructions = ?, notes = ?
        WHERE route_id = ?
    ");

    if (!$stmt) {
        respondAdminSave("error", "SQL prepare failed: " . $conn->error);
    }

    $stmt->bind_param(
        "ssssssdssssssisssssssi",
        $route_name,
        $category,
        $transport,
        $operator,
        $origin,
        $destination,
        $fare_value,
        $travel_time,
        $distance,
        $schedule,
        $tag,
        $status,
        $direction,
        $transfers,
        $badge,
        $stops,
        $landmarks,
        $reason,
        $walking,
        $instructions,
        $notes,
        $route_id
    );
} else {
    $stmt = $conn->prepare("
        INSERT INTO routes
        (route_name, category, transport, operator, origin, destination, fare, travel_time, distance, schedule, tag, status, direction, transfers, badge, stops, landmarks, reason, walking, instructions, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        respondAdminSave("error", "SQL prepare failed: " . $conn->error);
    }

    $stmt->bind_param(
        "ssssssdssssssisssssss",
        $route_name,
        $category,
        $transport,
        $operator,
        $origin,
        $destination,
        $fare_value,
        $travel_time,
        $distance,
        $schedule,
        $tag,
        $status,
        $direction,
        $transfers,
        $badge,
        $stops,
        $landmarks,
        $reason,
        $walking,
        $instructions,
        $notes
    );
}

if ($stmt->execute()) {
    $saved_id = $route_id > 0 ? $route_id : $stmt->insert_id;
    respondAdminSave("success", $route_id > 0 ? "Route updated successfully." : "Route added successfully.", $saved_id);
}

respondAdminSave("error", "Failed to save route: " . $stmt->error);

$stmt->close();
$conn->close();
?>
