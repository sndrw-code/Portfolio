<?php
session_start();
include "db.php";

header("Content-Type: application/json");


function ensureRouteColumn($conn, $column, $definition) {
    $safe_column = $conn->real_escape_string($column);
    $result = $conn->query("SHOW COLUMNS FROM routes LIKE '$safe_column'");

    if ($result && $result->num_rows === 0) {
        $conn->query("ALTER TABLE routes ADD COLUMN $column $definition");
    }
}

function ensureRouteSchema($conn) {
    ensureRouteColumn($conn, "direction", "varchar(50) DEFAULT NULL");
    ensureRouteColumn($conn, "transfers", "int(11) NOT NULL DEFAULT 0");
    ensureRouteColumn($conn, "badge", "varchar(50) DEFAULT 'badge-teal'");
    ensureRouteColumn($conn, "stops", "text");
    ensureRouteColumn($conn, "landmarks", "text");
    ensureRouteColumn($conn, "reason", "text");
    ensureRouteColumn($conn, "walking", "text");
    ensureRouteColumn($conn, "instructions", "text");
    ensureRouteColumn($conn, "notes", "text");
}


ensureRouteSchema($conn);

$count_result = $conn->query("SELECT COUNT(*) AS total FROM routes");
$count_row = $count_result ? $count_result->fetch_assoc() : ["total" => 0];

if (intval($count_row["total"] ?? 0) === 0 && file_exists(__DIR__ . "/seed_routes.php")) {
    include_once __DIR__ . "/seed_routes.php";

    if (function_exists("seedDefaultRoutes")) {
        seedDefaultRoutes($conn);
    }
}

$category = trim($_GET["category"] ?? "");
$search = trim($_GET["search"] ?? "");
$role = $_SESSION["role"] ?? "commuter";
$is_admin = ($role === "admin" || $role === "head_admin");

$where = [];
$types = "";
$params = [];

if (!$is_admin) {
    $where[] = "status = 'active'";
}

if ($category !== "") {
    $where[] = "category = ?";
    $types .= "s";
    $params[] = $category;
}

if ($search !== "") {
    $like = "%" . $search . "%";
    $where[] = "(route_name LIKE ? OR origin LIKE ? OR destination LIKE ? OR transport LIKE ? OR operator LIKE ? OR schedule LIKE ? OR tag LIKE ? OR CAST(fare AS CHAR) LIKE ?)";
    $types .= "ssssssss";
    for ($i = 0; $i < 8; $i++) {
        $params[] = $like;
    }
}

$sql = "
    SELECT
        route_id,
        category,
        route_name,
        transport,
        operator,
        origin,
        destination,
        fare,
        travel_time,
        distance,
        schedule,
        tag,
        status,
        direction,
        transfers,
        badge,
        stops,
        landmarks,
        reason,
        walking,
        instructions,
        notes
    FROM routes
";

if (count($where) > 0) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY FIELD(category, 'p2p', 'uv', 'jeepney', 'bus', 'ejeep'), route_name";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "status" => "error",
        "message" => "SQL prepare failed: " . $conn->error
    ]);
    exit();
}

if ($types !== "") {
    $bind_values = [];
    $bind_values[] = $types;

    for ($i = 0; $i < count($params); $i++) {
        $bind_values[] = &$params[$i];
    }

    call_user_func_array([$stmt, "bind_param"], $bind_values);
}

$stmt->execute();
$result = $stmt->get_result();
$routes = [];

while ($row = $result->fetch_assoc()) {
    $stops = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $row["stops"] ?? ""))));
    $landmarks = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $row["landmarks"] ?? ""))));

    if (count($stops) === 0) {
        $stops = [$row["origin"], $row["destination"]];
    }

    $routes[] = [
        "id" => strval($row["route_id"]),
        "route_id" => intval($row["route_id"]),
        "category" => $row["category"],
        "name" => $row["route_name"],
        "title" => $row["route_name"],
        "route_name" => $row["route_name"],
        "transport" => $row["transport"],
        "operator" => $row["operator"] ?? "",
        "company" => $row["operator"] ?? "",
        "origin" => $row["origin"],
        "destination" => $row["destination"],
        "route" => $row["origin"] . " → " . $row["destination"],
        "fare" => $row["fare"],
        "time" => $row["travel_time"],
        "travel_time" => $row["travel_time"],
        "distance" => $row["distance"],
        "schedule" => $row["schedule"],
        "tag" => $row["tag"] ?: "Available",
        "status" => $row["status"],
        "direction" => $row["direction"],
        "transfers" => intval($row["transfers"] ?? 0),
        "badge" => $row["badge"] ?: "badge-teal",
        "stops" => $stops,
        "landmarks" => $landmarks,
        "reason" => $row["reason"] ?? "",
        "walking" => $row["walking"] ?? "",
        "instructions" => $row["instructions"] ?? "",
        "notes" => $row["notes"] ?? ""
    ];
}

echo json_encode([
    "status" => "success",
    "routes" => $routes,
    "count" => count($routes)
]);

$stmt->close();
$conn->close();
?>
