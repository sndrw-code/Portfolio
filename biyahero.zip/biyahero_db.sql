-- BiyaHero updated database schema with seed routes
CREATE DATABASE IF NOT EXISTS `biyahero_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `biyahero_db`;

DROP TABLE IF EXISTS `routes`;
CREATE TABLE `routes` (
  `route_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  `route_name` varchar(150) NOT NULL,
  `transport` varchar(100) NOT NULL,
  `operator` varchar(150) DEFAULT NULL,
  `origin` varchar(150) NOT NULL,
  `destination` varchar(150) NOT NULL,
  `fare` decimal(10,2) NOT NULL,
  `travel_time` varchar(50) NOT NULL,
  `distance` varchar(50) DEFAULT NULL,
  `schedule` text,
  `tag` varchar(50) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `direction` varchar(50) DEFAULT NULL,
  `transfers` int(11) NOT NULL DEFAULT 0,
  `badge` varchar(50) DEFAULT 'badge-teal',
  `stops` text,
  `landmarks` text,
  `reason` text,
  `walking` text,
  `instructions` text,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`route_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `routes` (`category`, `route_name`, `transport`, `operator`, `origin`, `destination`, `fare`, `travel_time`, `distance`, `schedule`, `tag`, `status`, `direction`, `transfers`, `badge`, `stops`, `landmarks`, `reason`, `walking`, `instructions`, `notes`) VALUES
('p2p', 'Market! Market! → Alabang', 'P2P', 'Alabang Express', 'Market! Market! Terminal', 'Alabang Town Center', 150.00, '45', '35', '6:00 AM - 10:00 PM', 'Direct', 'active', '', 0, 'badge-teal', 'Market! Market!
MOA
Coastal Road
Alabang', 'Starting at M! M! transport hub
Pass by MOA Complex
End near shopping center', '', '', '', ''),
('p2p', 'Market! Market! → Balibago', 'P2P', 'Santa Rosa Express', 'Market! Market! Terminal', 'Balibago Terminal', 120.00, '40', '30', '6:30 AM - 9:30 PM', 'Direct', 'active', '', 0, 'badge-teal', 'Market! Market!
BGC
Muntinlupa
Balibago', 'Start at Market! Market!
Via BGC highway
End at Balibago', '', '', '', ''),
('p2p', 'Market! Market! → Calamba', 'P2P', 'Calamba Coach', 'Market! Market! Terminal', 'Calamba Terminal', 140.00, '50', '42', '7:00 AM - 8:00 PM', 'Direct', 'active', '', 0, 'badge-teal', 'Market! Market!
Rizal
Kawit
Calamba', 'Market! Market! starting point
Via Rizal highway
End at Calamba market', '', '', '', ''),
('p2p', 'Market! Market! → Pacita', 'P2P', 'Pacita Transport', 'Market! Market! Terminal', 'Pacita Complex Terminal', 110.00, '35', '25', '6:00 AM - 10:30 PM', 'Cheapest', 'active', '', 0, 'badge-teal', 'Market! Market!
Makati
Pacita', 'Board at M! M! transport hub
Via Makati business district
Arrive at Pacita complex', '', '', '', ''),
('uv', 'Market! Market! → Ayala (UV)', 'UV Express', 'UV Express Corp', 'Market! Market! UV Terminal', 'Ayala MRT Station', 45.00, '30', '12', 'Every 15 min • 6:00 AM - 10:00 PM', 'Popular', 'active', 'South', 0, 'badge-teal', 'Market! Market!
Ayala', 'Board at M! M! UV bay
Near Ayala shopping area', '', '', '', ''),
('uv', 'Market! Market! → Cavite (UV)', 'UV Express', 'UV Express Corp', 'Market! Market! UV Terminal', 'Cavite Terminal', 95.00, '50', '35', 'Every 30 min • 6:30 AM - 9:00 PM', 'Direct', 'active', 'South', 0, 'badge-teal', 'Market! Market!
Cavite', 'Start at M! M! UV station
End at Cavite market', '', '', '', ''),
('uv', 'Market! Market! → Taguig (UV)', 'UV Express', 'UV Express Corp', 'Market! Market! UV Terminal', 'BGC (Taguig) Terminal', 65.00, '25', '18', 'Every 20 min • 6:00 AM - 10:00 PM', 'Quick', 'active', 'South', 0, 'badge-teal', 'Market! Market!
BGC', 'Board at M! M!
BGC business district', '', '', '', ''),
('uv', 'Market! Market! → Antipolo (UV)', 'UV Express', 'Antipolo Express', 'Market! Market! UV Terminal', 'Antipolo Terminal', 85.00, '45', '32', 'Every 25 min • 6:00 AM - 9:00 PM', 'Direct', 'active', 'North', 0, 'badge-teal', 'Market! Market!
Antipolo', 'Start at M! M! UV bay
End at Antipolo market', '', '', '', ''),
('uv', 'Market! Market! → Marikina (UV)', 'UV Express', 'Marikina Transport', 'Market! Market! UV Terminal', 'Marikina Commercial Complex', 55.00, '35', '20', 'Every 20 min • 6:00 AM - 10:00 PM', 'Popular', 'active', 'North', 0, 'badge-teal', 'Market! Market!
Marikina', 'Board at M! M! UV station
Arrive near Marikina mall', '', '', '', ''),
('uv', 'Market! Market! → Pasig (UV)', 'UV Express', 'Pasig UV Transport', 'Market! Market! UV Terminal', 'Pasig Terminal', 50.00, '30', '18', 'Every 15 min • 6:00 AM - 10:00 PM', 'Quick', 'active', 'North', 0, 'badge-teal', 'Market! Market!
Pasig', 'Start at M! M!
Pasig commercial area', '', '', '', ''),
('uv', 'Market! Market! → Rosario (UV)', 'UV Express', 'Rosario Express', 'Market! Market! UV Terminal', 'Rosario Terminal', 75.00, '40', '28', 'Every 30 min • 6:30 AM - 9:00 PM', 'Direct', 'active', 'North', 0, 'badge-teal', 'Market! Market!
Rosario', 'Board at M! M! UV station
End at Rosario market', '', '', '', ''),
('jeepney', 'Market! Market! → Gate 3 (Jeepney)', 'Jeepney', 'Local Routes', 'Market! Market! Jeepney Stop', 'Gate 3 Terminal', 13.00, '40', '15', 'Every 10 min • 5:30 AM - 10:00 PM', 'Budget', 'active', 'South', 0, 'badge-teal', 'Market! Market!
Gate 3', 'Start at M! M! jeepney terminal
End at Gate 3 compound', '', '', '', ''),
('jeepney', 'Market! Market! → FTI C5 (Jeepney)', 'Jeepney', 'Local Routes', 'Market! Market! Jeepney Stop', 'FTI C5 Terminal', 13.00, '35', '12', 'Every 10 min • 5:30 AM - 10:00 PM', 'Direct', 'active', 'South', 0, 'badge-teal', 'Market! Market!
FTI C5', 'Board near M! M! mall
End at FTI industrial zone', '', '', '', ''),
('jeepney', 'Market! Market! → Ayala (Jeepney)', 'Jeepney', 'Local Routes', 'Market! Market! Jeepney Stop', 'Ayala Terminal', 15.00, '45', '18', 'Every 8 min • 5:30 AM - 11:00 PM', 'Popular', 'active', 'South', 0, 'badge-teal', 'Market! Market!
Ayala', 'Start at M! M! jeepney bay
Arrive at Ayala traffic', '', '', '', ''),
('jeepney', 'Market! Market! → Sucat (Jeepney)', 'Jeepney', 'Local Routes', 'Market! Market! Jeepney Stop', 'Sucat Terminal', 18.00, '55', '22', 'Every 12 min • 5:30 AM - 10:00 PM', 'First-Time Friendly', 'active', 'South', 0, 'badge-teal', 'Market! Market!
Sucat', 'Board at M! M!
Easy to identify Sucat stop', '', '', '', ''),
('jeepney', 'Market! Market! → Housing (Jeepney)', 'Jeepney', 'Local Routes', 'Market! Market! Jeepney Stop', 'Housing Terminal', 16.00, '50', '20', 'Every 15 min • 5:45 AM - 9:30 PM', 'Direct', 'active', 'South', 0, 'badge-teal', 'Market! Market!
Housing', 'Start at M! M! jeepney stop
End at residential area', '', '', '', ''),
('jeepney', 'Market! Market! → Pateros (Jeepney)', 'Jeepney', 'Local Routes', 'Market! Market! Jeepney Stop', 'Pateros Terminal', 14.00, '42', '16', 'Every 12 min • 5:30 AM - 10:00 PM', 'Budget', 'active', 'North', 0, 'badge-teal', 'Market! Market!
Pateros', 'Board near M! M!
End at Pateros market', '', '', '', ''),
('bus', 'Market! Market! → Rawis (Elavil Tours)', 'Bus', 'Elavil Tours Philippines', 'Market! Market! Bus Terminal', 'Rawis Terminal', 120.00, '3.5', '160', '7:00 AM, 10:00 AM, 2:00 PM, 5:00 PM', 'Intercity', 'active', '', 0, 'badge-teal', 'Market! Market!
Rawis', 'Board at M! M! bus bay
Arrive at Rawis town center', '', '', '', ''),
('bus', 'Market! Market! → Catarman (Elavil Tours)', 'Bus', 'Elavil Tours Philippines', 'Market! Market! Bus Terminal', 'Catarman Terminal', 140.00, '4', '185', '8:00 AM, 11:00 AM, 3:00 PM, 6:00 PM', 'Intercity', 'active', '', 0, 'badge-teal', 'Market! Market!
Catarman', 'Start at M! M! bus depot
End at Catarman town', '', '', '', ''),
('bus', 'Market! Market! → Prieto Diaz (Elavil Tours)', 'Bus', 'Elavil Tours Philippines', 'Market! Market! Bus Terminal', 'Prieto Diaz Terminal', 135.00, '3.75', '175', '7:30 AM, 10:30 AM, 2:30 PM, 5:30 PM', 'Intercity', 'active', '', 0, 'badge-teal', 'Market! Market!
Prieto Diaz', 'Board at M! M! bus station
Arrive at Prieto Diaz', '', '', '', ''),
('bus', 'Market! Market! → Bulusan (Elavil Tours)', 'Bus', 'Elavil Tours Philippines', 'Market! Market! Bus Terminal', 'Bulusan Terminal', 150.00, '4.5', '200', '8:30 AM, 12:00 PM, 4:00 PM, 7:00 PM', 'Intercity', 'active', '', 0, 'badge-teal', 'Market! Market!
Bulusan', 'Start at M! M! bus terminal
End at Bulusan town center', '', '', '', ''),
('ejeep', 'E-Jeep Network', 'E-Jeep', 'Digital Mobility Co', 'Market! Market!', 'Various Destinations', 20.00, 'Variable', 'Flexible', '24/7 Available', 'On-Demand', 'active', '', 0, 'badge-teal', 'Flexible routing', 'Book via mobile app', '', '', '', '');

DROP TABLE IF EXISTS `saved_routes`;
CREATE TABLE `saved_routes` (
  `saved_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `route_name` varchar(150) NOT NULL,
  `origin` varchar(150) NOT NULL,
  `destination` varchar(150) NOT NULL,
  `transport` varchar(50) NOT NULL,
  `fare` decimal(10,2) NOT NULL,
  `travel_time` varchar(50) NOT NULL,
  `saved_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`saved_id`),
  UNIQUE KEY `unique_saved_route` (`user_id`, `route_name`, `origin`, `destination`, `transport`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `role` enum('commuter','admin','head_admin') NOT NULL DEFAULT 'commuter',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`full_name`, `age`, `username`, `password`, `role`) VALUES
('Head Admin', 0, 'head_admin', '$2y$10$TkVieDBqkzBx4SXA4fT2hu1ik/W/0T.ShjIsweqMnmw7iRSdLmd0S', 'head_admin');