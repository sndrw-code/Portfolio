<?php
session_start();
include "db.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: index.html");
    exit();
}

if ($_SESSION["role"] !== "admin" && $_SESSION["role"] !== "head_admin") {
    header("Location: index.html");
    exit();
}

$routes = $conn->query("SELECT * FROM routes ORDER BY category, route_name");
?>

<!DOCTYPE html>
<html>
<head>
    <title>BiyaHero Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">

    <style>
        .admin-page {
            padding: 32px;
            max-width: 1300px;
            margin: auto;
        }

        .admin-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .admin-form-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
        }

        .admin-form-grid textarea,
        .admin-form-grid .full {
            grid-column: 1 / -1;
        }

        .admin-route-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
            margin-top: 20px;
        }

        .admin-route-card {
            position: relative;
        }

        .admin-card-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--border-default);
        }

        details.admin-edit-box {
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--border-default);
        }

        details.admin-edit-box summary {
            cursor: pointer;
            font-weight: 700;
            color: var(--text-brand);
            margin-bottom: 12px;
        }

        @media (max-width: 900px) {
            .admin-form-grid,
            .admin-route-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<div class="app-container is-authenticated">
    <main class="admin-page">

        <div class="section-header enhanced-section-header">
            <div>
                <span class="section-kicker">Admin View</span>
                <h2>BiyaHero Admin Dashboard</h2>
                <p>Welcome, <?php echo htmlspecialchars($_SESSION["full_name"]); ?>.</p>
                <p>Role: <strong><?php echo htmlspecialchars($_SESSION["role"]); ?></strong></p>
            </div>
        </div>

        <div class="admin-actions">
            <a href="index.html" class="btn btn-secondary">Open Commuter View</a>

            <form action="logout.php" method="POST">
                <button type="submit" class="btn btn-secondary">Logout</button>
            </form>
        </div>

        <?php if ($_SESSION["role"] === "head_admin") { ?>
            <div class="intelligence-surface" style="margin-top: 24px;">
                <h3>Add New Admin</h3>
                <p>Only the head admin can create another admin account.</p>

                <form action="add_admin.php" method="POST" class="admin-form-grid">
                    <input type="text" name="full_name" placeholder="Full Name" required>
                    <input type="number" name="age" placeholder="Age" required>
                    <input type="text" name="username" placeholder="Username" required>
                    <input type="password" name="password" placeholder="Password" required>

                    <button type="submit" class="btn btn-primary full">
                        Add Admin
                    </button>
                </form>
            </div>
        <?php } ?>

        <div class="intelligence-surface" style="margin-top: 24px;">
            <h3>Add New Route</h3>
            <p>Add a route that commuters can use.</p>

            <form action="save_route_admin.php" method="POST" class="admin-form-grid">
                <input type="hidden" name="route_id" value="">

                <input type="text" name="route_name" placeholder="Route Name" required>

                <select name="category" required>
                    <option value="">Select Category</option>
                    <option value="p2p">P2P</option>
                    <option value="uv">UV Express</option>
                    <option value="jeepney">Jeepney</option>
                    <option value="bus">Bus</option>
                    <option value="ejeep">E-Jeep</option>
                </select>

                <input type="text" name="transport" placeholder="Transport Type" required>
                <input type="text" name="operator" placeholder="Operator">

                <input type="text" name="origin" placeholder="Origin" required>
                <input type="text" name="destination" placeholder="Destination" required>
                <input type="number" step="0.01" name="fare" placeholder="Fare" required>
                <input type="text" name="travel_time" placeholder="Travel Time" required>

                <input type="text" name="distance" placeholder="Distance">
                <input type="text" name="tag" placeholder="Tag">

                <select name="status">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>

                <textarea name="schedule" placeholder="Schedule"></textarea>

                <button type="submit" class="btn btn-primary full">
                    Add Route
                </button>
            </form>
        </div>

        <div style="margin-top: 32px;">
            <div class="section-header enhanced-section-header">
                <div>
                    <span class="section-kicker">Route Management</span>
                    <h3>Commuter Routes</h3>
                    <p>Admins can edit or delete routes shown to commuters.</p>
                </div>
            </div>

            <div class="admin-route-grid">
                <?php if ($routes && $routes->num_rows > 0) { ?>
                    <?php while ($route = $routes->fetch_assoc()) { ?>
                        <div class="route-card premium-route-card admin-route-card">
                            <div class="route-header">
                                <div>
                                    <h4 class="route-title">
                                        <?php echo htmlspecialchars($route["route_name"]); ?>
                                    </h4>

                                    <p class="route-summary">
                                        <?php echo htmlspecialchars($route["operator"]); ?>
                                    </p>
                                </div>

                                <div class="badge badge-teal">
                                    <?php echo htmlspecialchars($route["tag"] ?: $route["category"]); ?>
                                </div>
                            </div>

                            <div class="route-details">
                                <div class="route-detail-item">
                                    <span class="route-detail-label">Fare</span>
                                    <span class="route-detail-value fare">
                                        ₱<?php echo htmlspecialchars($route["fare"]); ?>
                                    </span>
                                </div>

                                <div class="route-detail-item">
                                    <span class="route-detail-label">Time</span>
                                    <span class="route-detail-value">
                                        <?php echo htmlspecialchars($route["travel_time"]); ?>
                                    </span>
                                </div>

                                <div class="route-detail-item">
                                    <span class="route-detail-label">Transport</span>
                                    <span class="route-detail-value">
                                        <?php echo htmlspecialchars($route["transport"]); ?>
                                    </span>
                                </div>

                                <div class="route-detail-item">
                                    <span class="route-detail-label">Status</span>
                                    <span class="route-detail-value">
                                        <?php echo htmlspecialchars($route["status"]); ?>
                                    </span>
                                </div>
                            </div>

                            <p class="route-card-note" style="margin-top: 14px;">
                                <strong>Route:</strong>
                                <?php echo htmlspecialchars($route["origin"]); ?>
                                →
                                <?php echo htmlspecialchars($route["destination"]); ?>
                            </p>

                            <p class="route-card-note">
                                <strong>Schedule:</strong>
                                <?php echo htmlspecialchars($route["schedule"]); ?>
                            </p>

                            <details class="admin-edit-box">
                                <summary>Edit Route</summary>

                                <form action="save_route_admin.php" method="POST" class="admin-form-grid">
                                    <input type="hidden" name="route_id" value="<?php echo $route["route_id"]; ?>">

                                    <input type="text" name="route_name" value="<?php echo htmlspecialchars($route["route_name"]); ?>" required>

                                    <select name="category" required>
                                        <option value="p2p" <?php if ($route["category"] === "p2p") echo "selected"; ?>>P2P</option>
                                        <option value="uv" <?php if ($route["category"] === "uv") echo "selected"; ?>>UV Express</option>
                                        <option value="jeepney" <?php if ($route["category"] === "jeepney") echo "selected"; ?>>Jeepney</option>
                                        <option value="bus" <?php if ($route["category"] === "bus") echo "selected"; ?>>Bus</option>
                                        <option value="ejeep" <?php if ($route["category"] === "ejeep") echo "selected"; ?>>E-Jeep</option>
                                    </select>

                                    <input type="text" name="transport" value="<?php echo htmlspecialchars($route["transport"]); ?>" required>
                                    <input type="text" name="operator" value="<?php echo htmlspecialchars($route["operator"]); ?>">

                                    <input type="text" name="origin" value="<?php echo htmlspecialchars($route["origin"]); ?>" required>
                                    <input type="text" name="destination" value="<?php echo htmlspecialchars($route["destination"]); ?>" required>
                                    <input type="number" step="0.01" name="fare" value="<?php echo htmlspecialchars($route["fare"]); ?>" required>
                                    <input type="text" name="travel_time" value="<?php echo htmlspecialchars($route["travel_time"]); ?>" required>

                                    <input type="text" name="distance" value="<?php echo htmlspecialchars($route["distance"]); ?>">
                                    <input type="text" name="tag" value="<?php echo htmlspecialchars($route["tag"]); ?>">

                                    <select name="status">
                                        <option value="active" <?php if ($route["status"] === "active") echo "selected"; ?>>Active</option>
                                        <option value="inactive" <?php if ($route["status"] === "inactive") echo "selected"; ?>>Inactive</option>
                                    </select>

                                    <textarea name="schedule"><?php echo htmlspecialchars($route["schedule"]); ?></textarea>

                                    <button type="submit" class="btn btn-primary full">
                                        Save Changes
                                    </button>
                                </form>
                            </details>

                            <div class="admin-card-actions">
                                <a 
                                    href="delete_route_admin.php?id=<?php echo $route["route_id"]; ?>" 
                                    class="btn btn-secondary"
                                    onclick="return confirm('Delete this route?');">
                                    Delete Route
                                </a>
                            </div>
                        </div>
                    <?php } ?>
                <?php } else { ?>
                    <div class="empty-state">
                        <div class="empty-mark">R</div>
                        <p class="empty-title">No routes yet</p>
                        <p class="empty-text">Add routes using the form above.</p>
                    </div>
                <?php } ?>
            </div>
        </div>

    </main>
</div>

</body>
</html>