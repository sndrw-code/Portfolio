<?php
session_start();
header("Content-Type: application/json");
include "db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"] ?? "");
    $password = trim($_POST["password"] ?? "");

    if (empty($username) || empty($password)) {
        echo json_encode([
            "status" => "empty",
            "message" => "Please complete all fields."
        ]);
        exit();
    }

    $stmt = $conn->prepare("SELECT user_id, full_name, username, password, role FROM users WHERE username = ? LIMIT 1");

    if (!$stmt) {
        echo json_encode([
            "status" => "error",
            "message" => "Database query failed: " . $conn->error
        ]);
        exit();
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user["password"])) {
            session_regenerate_id(true);

            $_SESSION["user_id"] = $user["user_id"];
            $_SESSION["full_name"] = $user["full_name"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["role"] = $user["role"];

            echo json_encode([
                "status" => "success",
                "role" => $user["role"],
                "message" => "Login successful.",
                "user" => [
                    "user_id" => $user["user_id"],
                    "full_name" => $user["full_name"],
                    "username" => $user["username"]
                ]
            ]);
            exit();
        } else {
            echo json_encode([
                "status" => "wrong_password",
                "message" => "Incorrect password."
            ]);
            exit();
        }
    } else {
        echo json_encode([
            "status" => "user_not_found",
            "message" => "Username not found."
        ]);
        exit();
    }
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid request method."
    ]);
    exit();
}
?>