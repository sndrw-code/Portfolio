// ============================================
// APP STATE & DATA MODELS
// ============================================

let currentRoute = null;

const appState = {
    currentScreen: 'authScreen',
    currentTransport: 'any',
    currentPreference: 'firsttime',
    selectedRoute: null,
    currentCategory: 'p2p',
    previousScreen: 'homeScreen',
    isAdmin: false,
    isHeadAdmin: false
};

const routeDatabase = {
    p2p: [
        {
            id: 'p2p-1',
            name: 'Market! Market! → Alabang',
            transport: 'P2P',
            operator: 'Alabang Express',
            origin: 'Market! Market! Terminal',
            destination: 'Alabang Town Center',
            fare: 150,
            time: 45,
            distance: 35,
            transfers: 0,
            tag: 'Direct',
            stops: ['Market! Market!', 'MOA', 'Coastal Road', 'Alabang'],
            landmarks: ['Starting at M! M! transport hub', 'Pass by MOA Complex', 'End near shopping center'],
            schedule: '6:00 AM - 10:00 PM'
        },
        {
            id: 'p2p-2',
            name: 'Market! Market! → Balibago',
            transport: 'P2P',
            operator: 'Santa Rosa Express',
            origin: 'Market! Market! Terminal',
            destination: 'Balibago Terminal',
            fare: 120,
            time: 40,
            distance: 30,
            transfers: 0,
            tag: 'Direct',
            stops: ['Market! Market!', 'BGC', 'Muntinlupa', 'Balibago'],
            landmarks: ['Start at Market! Market!', 'Via BGC highway', 'End at Balibago'],
            schedule: '6:30 AM - 9:30 PM'
        },
        {
            id: 'p2p-3',
            name: 'Market! Market! → Calamba',
            transport: 'P2P',
            operator: 'Calamba Coach',
            origin: 'Market! Market! Terminal',
            destination: 'Calamba Terminal',
            fare: 140,
            time: 50,
            distance: 42,
            transfers: 0,
            tag: 'Direct',
            stops: ['Market! Market!', 'Rizal', 'Kawit', 'Calamba'],
            landmarks: ['Market! Market! starting point', 'Via Rizal highway', 'End at Calamba market'],
            schedule: '7:00 AM - 8:00 PM'
        },
        {
            id: 'p2p-4',
            name: 'Market! Market! → Pacita',
            transport: 'P2P',
            operator: 'Pacita Transport',
            origin: 'Market! Market! Terminal',
            destination: 'Pacita Complex Terminal',
            fare: 110,
            time: 35,
            distance: 25,
            transfers: 0,
            tag: 'Cheapest',
            stops: ['Market! Market!', 'Makati', 'Pacita'],
            landmarks: ['Board at M! M! transport hub', 'Via Makati business district', 'Arrive at Pacita complex'],
            schedule: '6:00 AM - 10:30 PM'
        }
    ],

    uv: [
        {
            id: 'uv-1',
            name: 'Market! Market! → Ayala (UV)',
            transport: 'UV Express',
            operator: 'UV Express Corp',
            direction: 'South',
            origin: 'Market! Market! UV Terminal',
            destination: 'Ayala MRT Station',
            fare: 45,
            time: 30,
            distance: 12,
            transfers: 0,
            tag: 'Popular',
            stops: ['Market! Market!', 'Ayala'],
            landmarks: ['Board at M! M! UV bay', 'Near Ayala shopping area'],
            schedule: 'Every 15 min • 6:00 AM - 10:00 PM'
        },
        {
            id: 'uv-2',
            name: 'Market! Market! → Cavite (UV)',
            transport: 'UV Express',
            operator: 'UV Express Corp',
            direction: 'South',
            origin: 'Market! Market! UV Terminal',
            destination: 'Cavite Terminal',
            fare: 95,
            time: 50,
            distance: 35,
            transfers: 0,
            tag: 'Direct',
            stops: ['Market! Market!', 'Cavite'],
            landmarks: ['Start at M! M! UV station', 'End at Cavite market'],
            schedule: 'Every 30 min • 6:30 AM - 9:00 PM'
        },
        {
            id: 'uv-3',
            name: 'Market! Market! → Taguig (UV)',
            transport: 'UV Express',
            operator: 'UV Express Corp',
            direction: 'South',
            origin: 'Market! Market! UV Terminal',
            destination: 'BGC (Taguig) Terminal',
            fare: 65,
            time: 25,
            distance: 18,
            transfers: 0,
            tag: 'Quick',
            stops: ['Market! Market!', 'BGC'],
            landmarks: ['Board at M! M!', 'BGC business district'],
            schedule: 'Every 20 min • 6:00 AM - 10:00 PM'
        },
        {
            id: 'uv-4',
            name: 'Market! Market! → Antipolo (UV)',
            transport: 'UV Express',
            operator: 'Antipolo Express',
            direction: 'North',
            origin: 'Market! Market! UV Terminal',
            destination: 'Antipolo Terminal',
            fare: 85,
            time: 45,
            distance: 32,
            transfers: 0,
            tag: 'Direct',
            stops: ['Market! Market!', 'Antipolo'],
            landmarks: ['Start at M! M! UV bay', 'End at Antipolo market'],
            schedule: 'Every 25 min • 6:00 AM - 9:00 PM'
        },
        {
            id: 'uv-5',
            name: 'Market! Market! → Marikina (UV)',
            transport: 'UV Express',
            operator: 'Marikina Transport',
            direction: 'North',
            origin: 'Market! Market! UV Terminal',
            destination: 'Marikina Commercial Complex',
            fare: 55,
            time: 35,
            distance: 20,
            transfers: 0,
            tag: 'Popular',
            stops: ['Market! Market!', 'Marikina'],
            landmarks: ['Board at M! M! UV station', 'Arrive near Marikina mall'],
            schedule: 'Every 20 min • 6:00 AM - 10:00 PM'
        },
        {
            id: 'uv-6',
            name: 'Market! Market! → Pasig (UV)',
            transport: 'UV Express',
            operator: 'Pasig UV Transport',
            direction: 'North',
            origin: 'Market! Market! UV Terminal',
            destination: 'Pasig Terminal',
            fare: 50,
            time: 30,
            distance: 18,
            transfers: 0,
            tag: 'Quick',
            stops: ['Market! Market!', 'Pasig'],
            landmarks: ['Start at M! M!', 'Pasig commercial area'],
            schedule: 'Every 15 min • 6:00 AM - 10:00 PM'
        },
        {
            id: 'uv-7',
            name: 'Market! Market! → Rosario (UV)',
            transport: 'UV Express',
            operator: 'Rosario Express',
            direction: 'North',
            origin: 'Market! Market! UV Terminal',
            destination: 'Rosario Terminal',
            fare: 75,
            time: 40,
            distance: 28,
            transfers: 0,
            tag: 'Direct',
            stops: ['Market! Market!', 'Rosario'],
            landmarks: ['Board at M! M! UV station', 'End at Rosario market'],
            schedule: 'Every 30 min • 6:30 AM - 9:00 PM'
        }
    ],

    jeepney: [
        {
            id: 'jp-1',
            name: 'Market! Market! → Gate 3 (Jeepney)',
            transport: 'Jeepney',
            operator: 'Local Routes',
            direction: 'South',
            origin: 'Market! Market! Jeepney Stop',
            destination: 'Gate 3 Terminal',
            fare: 13,
            time: 40,
            distance: 15,
            transfers: 0,
            tag: 'Budget',
            stops: ['Market! Market!', 'Gate 3'],
            landmarks: ['Start at M! M! jeepney terminal', 'End at Gate 3 compound'],
            schedule: 'Every 10 min • 5:30 AM - 10:00 PM'
        },
        {
            id: 'jp-2',
            name: 'Market! Market! → FTI C5 (Jeepney)',
            transport: 'Jeepney',
            operator: 'Local Routes',
            direction: 'South',
            origin: 'Market! Market! Jeepney Stop',
            destination: 'FTI C5 Terminal',
            fare: 13,
            time: 35,
            distance: 12,
            transfers: 0,
            tag: 'Direct',
            stops: ['Market! Market!', 'FTI C5'],
            landmarks: ['Board near M! M! mall', 'End at FTI industrial zone'],
            schedule: 'Every 10 min • 5:30 AM - 10:00 PM'
        },
        {
            id: 'jp-3',
            name: 'Market! Market! → Ayala (Jeepney)',
            transport: 'Jeepney',
            operator: 'Local Routes',
            direction: 'South',
            origin: 'Market! Market! Jeepney Stop',
            destination: 'Ayala Terminal',
            fare: 15,
            time: 45,
            distance: 18,
            transfers: 0,
            tag: 'Popular',
            stops: ['Market! Market!', 'Ayala'],
            landmarks: ['Start at M! M! jeepney bay', 'Arrive at Ayala traffic'],
            schedule: 'Every 8 min • 5:30 AM - 11:00 PM'
        },
        {
            id: 'jp-4',
            name: 'Market! Market! → Sucat (Jeepney)',
            transport: 'Jeepney',
            operator: 'Local Routes',
            direction: 'South',
            origin: 'Market! Market! Jeepney Stop',
            destination: 'Sucat Terminal',
            fare: 18,
            time: 55,
            distance: 22,
            transfers: 0,
            tag: 'First-Time Friendly',
            stops: ['Market! Market!', 'Sucat'],
            landmarks: ['Board at M! M!', 'Easy to identify Sucat stop'],
            schedule: 'Every 12 min • 5:30 AM - 10:00 PM'
        },
        {
            id: 'jp-5',
            name: 'Market! Market! → Housing (Jeepney)',
            transport: 'Jeepney',
            operator: 'Local Routes',
            direction: 'South',
            origin: 'Market! Market! Jeepney Stop',
            destination: 'Housing Terminal',
            fare: 16,
            time: 50,
            distance: 20,
            transfers: 0,
            tag: 'Direct',
            stops: ['Market! Market!', 'Housing'],
            landmarks: ['Start at M! M! jeepney stop', 'End at residential area'],
            schedule: 'Every 15 min • 5:45 AM - 9:30 PM'
        },
        {
            id: 'jp-6',
            name: 'Market! Market! → Pateros (Jeepney)',
            transport: 'Jeepney',
            operator: 'Local Routes',
            direction: 'North',
            origin: 'Market! Market! Jeepney Stop',
            destination: 'Pateros Terminal',
            fare: 14,
            time: 42,
            distance: 16,
            transfers: 0,
            tag: 'Budget',
            stops: ['Market! Market!', 'Pateros'],
            landmarks: ['Board near M! M!', 'End at Pateros market'],
            schedule: 'Every 12 min • 5:30 AM - 10:00 PM'
        }
    ],

    bus: [
        {
            id: 'bus-1',
            name: 'Market! Market! → Rawis (Elavil Tours)',
            transport: 'Bus',
            operator: 'Elavil Tours Philippines',
            origin: 'Market! Market! Bus Terminal',
            destination: 'Rawis Terminal',
            fare: 120,
            time: 3.5,
            distance: 160,
            transfers: 0,
            tag: 'Intercity',
            stops: ['Market! Market!', 'Rawis'],
            landmarks: ['Board at M! M! bus bay', 'Arrive at Rawis town center'],
            schedule: '7:00 AM, 10:00 AM, 2:00 PM, 5:00 PM'
        },
        {
            id: 'bus-2',
            name: 'Market! Market! → Catarman (Elavil Tours)',
            transport: 'Bus',
            operator: 'Elavil Tours Philippines',
            origin: 'Market! Market! Bus Terminal',
            destination: 'Catarman Terminal',
            fare: 140,
            time: 4,
            distance: 185,
            transfers: 0,
            tag: 'Intercity',
            stops: ['Market! Market!', 'Catarman'],
            landmarks: ['Start at M! M! bus depot', 'End at Catarman town'],
            schedule: '8:00 AM, 11:00 AM, 3:00 PM, 6:00 PM'
        },
        {
            id: 'bus-3',
            name: 'Market! Market! → Prieto Diaz (Elavil Tours)',
            transport: 'Bus',
            operator: 'Elavil Tours Philippines',
            origin: 'Market! Market! Bus Terminal',
            destination: 'Prieto Diaz Terminal',
            fare: 135,
            time: 3.75,
            distance: 175,
            transfers: 0,
            tag: 'Intercity',
            stops: ['Market! Market!', 'Prieto Diaz'],
            landmarks: ['Board at M! M! bus station', 'Arrive at Prieto Diaz'],
            schedule: '7:30 AM, 10:30 AM, 2:30 PM, 5:30 PM'
        },
        {
            id: 'bus-4',
            name: 'Market! Market! → Bulusan (Elavil Tours)',
            transport: 'Bus',
            operator: 'Elavil Tours Philippines',
            origin: 'Market! Market! Bus Terminal',
            destination: 'Bulusan Terminal',
            fare: 150,
            time: 4.5,
            distance: 200,
            transfers: 0,
            tag: 'Intercity',
            stops: ['Market! Market!', 'Bulusan'],
            landmarks: ['Start at M! M! bus terminal', 'End at Bulusan town center'],
            schedule: '8:30 AM, 12:00 PM, 4:00 PM, 7:00 PM'
        }
    ],

    ejeep: [
        {
            id: 'ej-1',
            name: 'E-Jeep Network',
            transport: 'E-Jeep',
            operator: 'Digital Mobility Co',
            origin: 'Market! Market!',
            destination: 'Various Destinations',
            fare: 20,
            time: 'Variable',
            distance: 'Flexible',
            transfers: 0,
            tag: 'On-Demand',
            stops: ['Flexible routing'],
            landmarks: ['Book via mobile app'],
            schedule: '24/7 Available'
        }
    ]
};

// ============================================
// NAVIGATION & SCREEN MANAGEMENT
// ============================================

function navigateScreen(screenId, navItem) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });

    const screen = document.getElementById(screenId);

    if (screen) {
        screen.classList.add('active');
        appState.currentScreen = screenId;
    }

    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });

    if (navItem) {
        navItem.classList.add('active');
    }

    if (screenId === 'savedScreen' || screenId === 'savedRoutesScreen') {
        getSavedRoutes();
    }
}

function navigateToHome() {
    document.getElementById('authScreen').classList.remove('active');
    document.querySelector('.app-container').classList.add('is-authenticated');

    navigateScreen(
        'homeScreen',
        document.querySelector('.topbar-nav [data-screen="homeScreen"]')
    );

    getSavedRoutes();
}

// ============================================
// AUTH FORM HANDLING
// ============================================

function toggleAuthForm() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    if (loginForm.style.display !== 'none') {
        loginForm.style.display = 'none';
        registerForm.style.display = 'flex';
    } else {
        loginForm.style.display = 'flex';
        registerForm.style.display = 'none';
    }
}

// ============================================
// HOME SCREEN - ROUTE FINDER
// ============================================

function selectTransport(chip) {
    document.querySelectorAll('[data-transport]').forEach(chipItem => {
        chipItem.classList.remove('active');
    });

    chip.classList.add('active');
    appState.currentTransport = chip.dataset.transport;
}

function selectPreference(chip) {
    document.querySelectorAll('[data-preference]').forEach(chipItem => {
        chipItem.classList.remove('active');
    });

    chip.classList.add('active');
    appState.currentPreference = chip.dataset.preference;
}

function generateRouteResults(origin, destination) {
    return [
        {
            title: 'Option 1 - First-Time Friendly',
            name: `${origin} → ${destination}`,
            tag: 'First-Time Friendly',
            badge: 'badge-teal',
            route: `${origin} → ${destination}`,
            origin: origin,
            destination: destination,
            transport: 'Jeepney + Walking',
            time: 45,
            fare: 18,
            arrivals: '2:35 PM',
            transfers: 0,
            reason: 'Simple route, easy to follow, clear boarding points',
            walking: 'Minimal walking',
            steps: 5
        },
        {
            title: 'Option 2 - Cheapest',
            name: `${origin} → ${destination}`,
            tag: 'Cheapest',
            badge: 'badge-amber',
            route: `${origin} → ${destination}`,
            origin: origin,
            destination: destination,
            transport: 'Jeepney',
            time: 50,
            fare: 13,
            arrivals: '2:40 PM',
            transfers: 0,
            reason: 'Lowest total fare',
            walking: 'Moderate walking',
            steps: 4
        },
        {
            title: 'Option 3 - Fastest',
            name: `${origin} → ${destination}`,
            tag: 'Fastest',
            badge: 'badge-fare',
            route: `${origin} → ${destination}`,
            origin: origin,
            destination: destination,
            transport: 'UV Express',
            time: 30,
            fare: 45,
            arrivals: '2:15 PM',
            transfers: 0,
            reason: 'Shortest travel time',
            walking: 'Least walking',
            steps: 3
        }
    ];
}

function displayRouteResults(results) {
    const container = document.getElementById('routeResults');
    container.innerHTML = '';

    results.forEach(result => {
        const card = document.createElement('div');
        card.className = 'route-card premium-route-card';

        card.innerHTML = `
            <div class="route-header">
                <div>
                    <h4 class="route-title">${result.title}</h4>
                    <p class="route-summary">${result.route}</p>
                </div>
                <div class="badge ${result.badge}">${result.tag}</div>
            </div>

            <div class="route-details">
                <div class="route-detail-item">
                    <span class="route-detail-label">Time</span>
                    <span class="route-detail-value">${result.time} min</span>
                </div>

                <div class="route-detail-item">
                    <span class="route-detail-label">Fare</span>
                    <span class="route-detail-value fare">₱${result.fare}</span>
                </div>

                <div class="route-detail-item">
                    <span class="route-detail-label">Arrival</span>
                    <span class="route-detail-value">${result.arrivals}</span>
                </div>

                <div class="route-detail-item">
                    <span class="route-detail-label">Transfers</span>
                    <span class="route-detail-value">${result.transfers}</span>
                </div>
            </div>

            <div style="margin-top: var(--spacing-sm); padding-top: var(--spacing-base); border-top: 1px solid var(--border-default);">
                <p class="route-card-note" style="margin: 0 0 var(--spacing-sm) 0;">
                    <strong>Recommended because:</strong> ${result.reason}
                </p>

                <button class="btn btn-primary btn-sm" onclick="openRouteDetail(${JSON.stringify(result).replace(/"/g, '&quot;')})">
                    View BiyaHero Guide
                </button>
            </div>
        `;

        container.appendChild(card);
    });
}

function restoreSearch(origin, destination) {
    document.getElementById('searchOrigin').value = origin;
    document.getElementById('searchDestination').value = destination;

    navigateScreen(
        'homeScreen',
        document.querySelector('.topbar-nav [data-screen="homeScreen"]')
    );

    setTimeout(() => {
        findRoutes();
    }, 100);
}

// ============================================
// ROUTE DETAILS / BIYAHERO GUIDE
// ============================================

function formatRouteTime(value) {
    if (value === undefined || value === null || value === '') {
        return 'N/A';
    }

    const textValue = String(value);

    if (/min|hr|hour|variable/i.test(textValue)) {
        return textValue;
    }

    return `${textValue} min`;
}

function closeRouteDetail() {
    const targetScreen = appState.previousScreen || 'homeScreen';
    const target = document.getElementById(targetScreen) || document.getElementById('homeScreen');

    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });

    target.classList.add('active');
    appState.currentScreen = target.id;

    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });

    const navItem = document.querySelector(`[data-screen="${target.id}"]`);

    if (navItem) {
        navItem.classList.add('active');
    }
}

function closeRouteModal() {
    closeRouteDetail();
}

function toggleVoiceGuide() {
    const toggle = document.getElementById('voiceToggle');
    const preview = document.getElementById('voicePreview');

    if (!toggle || !preview) {
        return;
    }

    toggle.classList.toggle('active');
    preview.style.display = toggle.classList.contains('active') ? 'block' : 'none';
}

// ============================================
// RECENT SEARCHES
// ============================================

const RECENT_SEARCHES_KEY = "biyahero_recent_searches";

function saveRecentSearch(origin, destination) {
    let recentSearches = JSON.parse(localStorage.getItem(RECENT_SEARCHES_KEY)) || [];

    recentSearches = recentSearches.filter(search => {
        return !(
            search.origin.toLowerCase() === origin.toLowerCase() &&
            search.destination.toLowerCase() === destination.toLowerCase()
        );
    });

    recentSearches.unshift({
        origin: origin,
        destination: destination,
        searched_at: new Date().toISOString()
    });

    recentSearches = recentSearches.slice(0, 5);

    localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(recentSearches));

    displayRecentSearches();
}

function displayRecentSearches() {
    const container = document.getElementById("recentSearchesContainer");

    if (!container) {
        return;
    }

    const recentSearches = JSON.parse(localStorage.getItem(RECENT_SEARCHES_KEY)) || [];

    container.innerHTML = "";

    if (recentSearches.length === 0) {
        container.innerHTML = "<p>No recent searches yet.</p>";
        return;
    }

    recentSearches.forEach(search => {
        const item = document.createElement("div");
        item.classList.add("list-item");

        item.onclick = function () {
            restoreSearch(search.origin, search.destination);
        };

        item.innerHTML = `
            <div class="list-item-content">
                <p class="list-item-title">${search.origin} → ${search.destination}</p>
                <p class="list-item-subtitle">Tap to search again</p>
            </div>
            <span class="list-item-arrow">→</span>
        `;

        container.appendChild(item);
    });
}

function clearRecentSearches() {
    localStorage.removeItem(RECENT_SEARCHES_KEY);
    displayRecentSearches();
}

// ============================================
// SAVE ROUTE / GET SAVED ROUTES
// ============================================

function getSavedRoutes() {
    const savedRoutesContainer = document.getElementById("savedRoutesContainer");

    if (!savedRoutesContainer) {
        return;
    }

    fetch("get_saved_routes.php", {
        credentials: "same-origin"
    })
        .then(response => response.json())
        .then(data => {
            savedRoutesContainer.innerHTML = "";

            if (data.status === "error") {
                savedRoutesContainer.innerHTML = `<p>${data.message}</p>`;
                return;
            }

            if (!data.routes || data.routes.length === 0) {
    updateTrackerCounts(0);
    savedRoutesContainer.innerHTML = "<p>No saved routes yet.</p>";
    return;
}

updateTrackerCounts(data.routes.length);

            data.routes.forEach(route => {
                const routeItem = document.createElement("div");
                routeItem.classList.add("list-item");

                routeItem.onclick = function () {
                    openRouteDetail({
                        name: route.route_name,
                        route: `${route.origin} → ${route.destination}`,
                        origin: route.origin,
                        destination: route.destination,
                        transport: route.transport,
                        fare: route.fare,
                        time: route.travel_time,
                        travel_time: route.travel_time,
                        transfers: 0,
                        tag: "Saved",
                        badge: "badge-teal"
                    });
                };

                routeItem.innerHTML = `
                    <div class="list-item-content">
                    <p class="list-item-title">${route.route_name}</p>
                    <p class="list-item-subtitle">
                        ${route.transport} • ₱${route.fare} • ${route.travel_time}
                    </p>
                    </div>

                    <div style="display: flex; align-items: center; gap: 10px;">
                    <button 
                        type="button" 
                        class="btn btn-secondary btn-sm"
                        onclick="event.stopPropagation(); deleteSavedRoute(${route.saved_id});">
                        Remove
                    </button>

                    <span class="list-item-arrow">→</span>
                    </div>
                `;

                savedRoutesContainer.appendChild(routeItem);
            });
        })
        .catch(error => {
            console.error("Error:", error);
            savedRoutesContainer.innerHTML = "<p>Something went wrong while loading saved routes.</p>";
        });
}

// ============================================
// ROUTES TAB - DIRECTORY
// ============================================

function switchCategory(tab) {
    document.querySelectorAll('.tab').forEach(tabItem => {
        tabItem.classList.remove('active');
    });

    tab.classList.add('active');
    appState.currentCategory = tab.dataset.category;

    displayRoutesByCategory(tab.dataset.category);
}

function displayRoutesByCategory(category) {
    const routes = routeDatabase[category] || [];
    const container = document.getElementById('routesList');

    if (!container) {
        return;
    }

    container.innerHTML = '';

    if (routes.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-mark" aria-hidden="true">R</div>
                <p class="empty-title">Coming Soon</p>
                <p class="empty-text">Routes for this transport type will be available soon</p>
            </div>
        `;
        return;
    }

    routes.forEach(route => {
        const card = document.createElement('div');
        card.className = 'route-card premium-route-card';

        card.onclick = function () {
            openRouteDetail(route);
        };

        const adminControls = appState.isAdmin
            ? `
                <div class="admin-route-actions">
                    <button 
                        type="button" 
                        class="btn btn-secondary btn-sm"
                        onclick="event.stopPropagation(); editRouteAdmin('${category}', '${route.id}')">
                        Edit
                    </button>

                    <button 
                        type="button" 
                        class="btn btn-secondary btn-sm"
                        onclick="event.stopPropagation(); deleteRouteAdmin('${category}', '${route.id}')">
                        Delete
                    </button>
                </div>
            `
            : "";

        card.innerHTML = `
            <div class="route-header">
                <div>
                    <h4 class="route-title">${route.name}</h4>
                    <p class="route-summary">${route.operator || route.direction || ''}</p>
                </div>

                <div class="badge badge-teal">${route.tag || 'Available'}</div>
            </div>

            <div class="route-details">
                <div class="route-detail-item">
                    <span class="route-detail-label">Fare</span>
                    <span class="route-detail-value fare">₱${route.fare}</span>
                </div>

                <div class="route-detail-item">
                    <span class="route-detail-label">Time</span>
                    <span class="route-detail-value">${formatRouteTime(route.time)}</span>
                </div>

                <div class="route-detail-item">
                    <span class="route-detail-label">Distance</span>
                    <span class="route-detail-value">${route.distance}${typeof route.distance === 'number' ? ' km' : ''}</span>
                </div>

                <div class="route-detail-item">
                    <span class="route-detail-label">Transport</span>
                    <span class="route-detail-value">${route.transport}</span>
                </div>
            </div>

            <div class="route-detail-item" style="margin-top: var(--spacing-base);">
                <span class="route-detail-label">Schedule</span>
                <span class="route-detail-value">${route.schedule || "No schedule"}</span>
            </div>

            <p class="route-card-note" style="margin: var(--spacing-base) 0 0 0;">
                Note: Student, Senior Citizen, and PWD discounts may apply
            </p>

            ${adminControls}
        `;

        container.appendChild(card);
    });
}

// ============================================
// FARE CALCULATOR
// ============================================

const fareData = {
    jeepney: { baseFare: 13, perKm: 1.50 },
    uv: { baseFare: 20, perKm: 2.00 },
    bus: { baseFare: 25, perKm: 1.75 },
    ejeep: { baseFare: 20, perKm: 2.50 },
    p2p: { baseFare: 50, perKm: 3.00 }
};

function updateFareInfo() {
    const fareTransport = document.getElementById('fareTransport');
    const fareInfo = document.getElementById('fareInfo');

    if (!fareTransport || !fareInfo) {
        return;
    }

    const type = fareTransport.value;
    const data = fareData[type];

    fareInfo.textContent = `Base fare: ₱${data.baseFare} + ₱${data.perKm}/km`;

    calculateFare();
}

function calculateFare() {
    const fareTransport = document.getElementById('fareTransport');
    const fareDistance = document.getElementById('fareDistance');
    const fareDiscount = document.getElementById('fareDiscount');

    if (!fareTransport || !fareDistance || !fareDiscount) {
        return;
    }

    const type = fareTransport.value;
    const distance = parseFloat(fareDistance.value) || 0;
    const discount = fareDiscount.value;
    const data = fareData[type];

    const baseFare = data.baseFare;
    const additional = distance * data.perKm;
    const subtotal = baseFare + additional;

    let discountAmount = 0;

    if (discount !== 'none') {
        discountAmount = subtotal * 0.20;
    }

    const total = subtotal - discountAmount;

    document.getElementById('fareBasic').textContent = `₱${baseFare.toFixed(2)}`;
    document.getElementById('fareAdditional').textContent = `₱${additional.toFixed(2)}`;
    document.getElementById('fareSubtotal').textContent = `₱${subtotal.toFixed(2)}`;
    document.getElementById('fareDiscountAmt').textContent = `₱${discountAmount.toFixed(2)}`;
    document.getElementById('fareTotalAmt').textContent = `₱${total.toFixed(2)}`;
}

// ============================================
// AUTH FUNCTIONS
// ============================================

// ============================================
// FULL ADMIN EDITOR
// Allows admins to edit routes, company/operator,
// schedule, time, fare, stops, landmarks, texts,
// taglines, and fare rules.
// ============================================

const ADMIN_SITE_TEXT_KEY = "biyahero_site_texts";
const ADMIN_FARE_RULES_KEY = "biyahero_fare_rules";

const adminSiteTextFields = [
    {
        key: "homeHeaderTitle",
        label: "Home Header Title",
        selector: "#homeScreen .header-title",
        defaultValue: "Find Your Route"
    },
    {
        key: "homeHeaderSubtitle",
        label: "Home Header Subtitle",
        selector: "#homeScreen .header-subtitle",
        defaultValue: "Search routes, compare fares, and get step-by-step guidance across PUV options."
    },
    {
        key: "homeSearchKicker",
        label: "Search Panel Kicker",
        selector: "#homeScreen .search-panel-intro .section-kicker",
        defaultValue: "Route planning workspace"
    },
    {
        key: "homeSearchTitle",
        label: "Search Panel Title",
        selector: "#homeScreen .search-panel-title",
        defaultValue: "Plan a clear commute from Market! Market!"
    },
    {
        key: "homeSearchDescription",
        label: "Search Panel Description",
        selector: "#homeScreen .search-panel-intro p",
        defaultValue: "Compare transport modes, fare estimates, and first-time-friendly BiyaHero Guide instructions in one focused workspace."
    },
    {
        key: "routesHeaderTitle",
        label: "Routes Header Title",
        selector: "#routesScreen .header-title",
        defaultValue: "Routes"
    },
    {
        key: "routesHeaderSubtitle",
        label: "Routes Header Subtitle",
        selector: "#routesScreen .header-subtitle",
        defaultValue: "Browse available PUV routes"
    },
    {
        key: "routesDirectoryKicker",
        label: "Transport Directory Kicker",
        selector: "#routesScreen .directory-tabs-card .section-kicker",
        defaultValue: "Transport directory"
    },
    {
        key: "routesDirectoryTitle",
        label: "Transport Directory Title",
        selector: "#routesScreen .directory-tabs-card h2",
        defaultValue: "Choose a route family"
    },
    {
        key: "fareHeaderTitle",
        label: "Fare Header Title",
        selector: "#fareScreen .header-title",
        defaultValue: "Fare Calculator"
    },
    {
        key: "fareHeaderSubtitle",
        label: "Fare Header Subtitle",
        selector: "#fareScreen .header-subtitle",
        defaultValue: "Estimate your travel fare"
    },
    {
        key: "farePanelKicker",
        label: "Fare Panel Kicker",
        selector: "#fareScreen .search-panel-intro .section-kicker",
        defaultValue: "Fare workspace"
    },
    {
        key: "farePanelTitle",
        label: "Fare Panel Title",
        selector: "#fareScreen .search-panel-title",
        defaultValue: "Calculate a readable commute estimate."
    },
    {
        key: "farePanelDescription",
        label: "Fare Panel Description",
        selector: "#fareScreen .search-panel-intro p",
        defaultValue: "Keep base fare, added distance cost, discount logic, and total amount visible in one decision panel."
    },
    {
        key: "savedHeaderTitle",
        label: "Saved Header Title",
        selector: "#savedScreen .header-title",
        defaultValue: "Saved"
    },
    {
        key: "savedHeaderSubtitle",
        label: "Saved Header Subtitle",
        selector: "#savedScreen .header-subtitle",
        defaultValue: "Your routes and search history"
    },
    {
        key: "recentSearchKicker",
        label: "Recent Search Kicker",
        selector: "#savedScreen .saved-section-card:nth-of-type(1) .section-kicker",
        defaultValue: "Recent search memory"
    },
    {
        key: "recentSearchTitle",
        label: "Recent Search Title",
        selector: "#savedScreen .saved-section-card:nth-of-type(1) h3",
        defaultValue: "Recent Searches"
    },
    {
        key: "savedRoutesKicker",
        label: "Saved Routes Kicker",
        selector: "#savedScreen .saved-section-card:nth-of-type(2) .section-kicker",
        defaultValue: "Reusable commute guides"
    },
    {
        key: "savedRoutesTitle",
        label: "Saved Routes Title",
        selector: "#savedScreen .saved-section-card:nth-of-type(2) h3",
        defaultValue: "Saved Routes"
    },
    {
        key: "adminModeTitle",
        label: "Admin Mode Title",
        selector: "#adminModeBar strong",
        defaultValue: "Admin Mode"
    },
    {
        key: "adminModeSubtitle",
        label: "Admin Mode Subtitle",
        selector: "#adminModeBar span",
        defaultValue: "You are viewing the same commuter interface with editing controls."
    }
];

function adminEscape(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

function adminParseValue(value) {
    const cleanValue = String(value ?? "").trim();

    if (cleanValue === "") {
        return "";
    }

    const numericValue = Number(cleanValue);

    if (Number.isNaN(numericValue)) {
        return cleanValue;
    }

    return numericValue;
}

function adminListToText(value) {
    if (Array.isArray(value)) {
        return value.join("\n");
    }

    return String(value ?? "");
}

function adminTextToList(value) {
    return String(value ?? "")
        .split(/\n|,/)
        .map(item => item.trim())
        .filter(item => item !== "");
}

function ensureAdminEditorStyles() {
    if (document.getElementById("adminEditorStyles")) {
        return;
    }

    const style = document.createElement("style");
    style.id = "adminEditorStyles";

    style.textContent = `
        .admin-editor-overlay {
            position: fixed;
            inset: 0;
            z-index: 99999;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 24px;
            background: rgba(8, 17, 32, 0.68);
            backdrop-filter: blur(10px);
        }

        .admin-editor-overlay.is-open {
            display: flex;
        }

        .admin-editor-modal {
            width: min(100%, 980px);
            max-height: 90vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            background: var(--bg-surface);
            border: 1px solid var(--border-default);
            border-radius: var(--radius-2xl);
            box-shadow: 0 30px 90px rgba(8, 17, 32, 0.28);
        }

        .admin-editor-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: var(--spacing-lg);
            padding: var(--spacing-xl);
            border-bottom: 1px solid var(--border-default);
            background: linear-gradient(135deg, rgba(15, 118, 110, 0.08), rgba(37, 99, 235, 0.06));
        }

        .admin-editor-header h2 {
            margin: 0;
            font-size: var(--type-section-size);
            color: var(--text-brand);
        }

        .admin-editor-header p {
            margin: var(--spacing-xs) 0 0 0;
            color: var(--text-secondary);
        }

        .admin-editor-close {
            width: 42px;
            height: 42px;
            border-radius: var(--radius-lg);
            background: var(--bg-surface);
            border: 1px solid var(--border-default);
            color: var(--text-brand);
            font-size: 1.25rem;
        }

        .admin-editor-body {
            padding: var(--spacing-xl);
            overflow-y: auto;
        }

        .admin-editor-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: var(--spacing-lg);
        }

        .admin-editor-field {
            display: flex;
            flex-direction: column;
            gap: var(--spacing-sm);
        }

        .admin-editor-field.full {
            grid-column: 1 / -1;
        }

        .admin-editor-field label {
            font-size: var(--type-label-size);
            font-weight: var(--font-weight-semibold);
            color: var(--text-brand);
        }

        .admin-editor-field small {
            color: var(--text-secondary);
            line-height: 1.4;
        }

        .admin-editor-footer {
            display: flex;
            justify-content: flex-end;
            gap: var(--spacing-base);
            padding: var(--spacing-lg) var(--spacing-xl);
            border-top: 1px solid var(--border-default);
            background: var(--bg-surface-subtle);
        }

        .admin-route-actions {
            display: flex;
            gap: var(--spacing-sm);
            flex-wrap: wrap;
            margin-top: var(--spacing-lg);
            padding-top: var(--spacing-base);
            border-top: 1px solid var(--border-default);
        }

        .admin-mode-actions {
            display: flex;
            align-items: center;
            gap: var(--spacing-sm);
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        @media (max-width: 720px) {
            .admin-editor-grid {
                grid-template-columns: 1fr;
            }

            .admin-editor-footer {
                flex-direction: column;
            }

            .admin-editor-footer .btn {
                width: 100%;
            }
        }
    `;

    document.head.appendChild(style);
}

function ensureAdminEditorModal() {
    ensureAdminEditorStyles();

    if (document.getElementById("adminEditorOverlay")) {
        return;
    }

    const overlay = document.createElement("div");
    overlay.id = "adminEditorOverlay";
    overlay.className = "admin-editor-overlay";

    overlay.innerHTML = `
        <div class="admin-editor-modal" role="dialog" aria-modal="true">
            <div class="admin-editor-header">
                <div>
                    <h2 id="adminEditorTitle">Admin Editor</h2>
                    <p id="adminEditorSubtitle">Edit commuter-facing information.</p>
                </div>

                <button type="button" class="admin-editor-close" onclick="closeAdminEditor()">×</button>
            </div>

            <div class="admin-editor-body" id="adminEditorBody"></div>

            <div class="admin-editor-footer" id="adminEditorFooter"></div>
        </div>
    `;

    document.body.appendChild(overlay);
}

function openAdminEditor(title, subtitle, bodyHTML, footerHTML) {
    ensureAdminEditorModal();

    document.getElementById("adminEditorTitle").textContent = title;
    document.getElementById("adminEditorSubtitle").textContent = subtitle;
    document.getElementById("adminEditorBody").innerHTML = bodyHTML;
    document.getElementById("adminEditorFooter").innerHTML = footerHTML;

    document.getElementById("adminEditorOverlay").classList.add("is-open");
}

function closeAdminEditor() {
    const overlay = document.getElementById("adminEditorOverlay");

    if (overlay) {
        overlay.classList.remove("is-open");
    }
}

function adminInput(label, name, value, type = "text", full = false, help = "") {
    return `
        <div class="admin-editor-field ${full ? "full" : ""}">
            <label for="adminRoute_${adminEscape(name)}">${adminEscape(label)}</label>
            <input 
                type="${adminEscape(type)}" 
                id="adminRoute_${adminEscape(name)}" 
                name="${adminEscape(name)}" 
                value="${adminEscape(value)}"
            >
            ${help ? `<small>${adminEscape(help)}</small>` : ""}
        </div>
    `;
}

function adminTextarea(label, name, value, full = true, help = "") {
    return `
        <div class="admin-editor-field ${full ? "full" : ""}">
            <label for="adminRoute_${adminEscape(name)}">${adminEscape(label)}</label>
            <textarea 
                id="adminRoute_${adminEscape(name)}" 
                name="${adminEscape(name)}" 
                rows="4"
            >${adminEscape(value)}</textarea>
            ${help ? `<small>${adminEscape(help)}</small>` : ""}
        </div>
    `;
}

function openAddRoutePrompt() {
    openAdminRouteEditor(appState.currentCategory || "p2p", null);
}

function editRouteAdmin(category, routeId) {
    openAdminRouteEditor(category, routeId);
}

function openAdminRouteEditor(category, routeId) {
    if (!adminHasAccess()) {
        return;
    }

    const currentCategory = category || appState.currentCategory || "p2p";

    if (!routeDatabase[currentCategory]) {
        routeDatabase[currentCategory] = [];
    }

    const route = routeId
        ? routeDatabase[currentCategory].find(item => item.id === routeId)
        : null;

    const isEditing = Boolean(route);

    const routeData = route || {
        id: "",
        name: "",
        transport: "",
        operator: "",
        company: "",
        direction: "",
        origin: "",
        destination: "",
        fare: "",
        time: "",
        distance: "",
        transfers: 0,
        tag: "Available",
        badge: "badge-teal",
        schedule: "",
        stops: [],
        landmarks: [],
        reason: "",
        walking: "",
        notes: "",
        instructions: ""
    };

    const categoryOptions = Object.keys(routeDatabase).map(item => {
        return `
            <option value="${adminEscape(item)}" ${item === currentCategory ? "selected" : ""}>
                ${adminEscape(item.toUpperCase())}
            </option>
        `;
    }).join("");

    const bodyHTML = `
        <form id="adminRouteEditorForm" data-old-category="${adminEscape(currentCategory)}" data-route-id="${adminEscape(routeId || "")}">
            <div class="admin-editor-grid">
                <div class="admin-editor-field">
                    <label for="adminRoute_category">Route Family / Category</label>
                    <select id="adminRoute_category" name="category">
                        ${categoryOptions}
                    </select>
                </div>

                ${adminInput("Route Name", "name", routeData.name || routeData.title || routeData.route_name || "")}
                ${adminInput("Transport Type", "transport", routeData.transport || "", "text", false, "Example: P2P, UV Express, Jeepney, Bus, E-Jeep")}
                ${adminInput("Company / Operator", "operator", routeData.operator || routeData.company || "", "text", false, "This edits the company/operator shown in the card.")}
                ${adminInput("Origin", "origin", routeData.origin || "")}
                ${adminInput("Destination", "destination", routeData.destination || "")}
                ${adminInput("Direction", "direction", routeData.direction || "", "text", false, "Optional. Example: North, South, East, West.")}
                ${adminInput("Fare", "fare", routeData.fare ?? "", "text", false, "Example: 45")}
                ${adminInput("Travel Time", "time", routeData.time ?? routeData.travel_time ?? "", "text", false, "Example: 30 or 1 hr 30 min")}
                ${adminInput("Distance", "distance", routeData.distance ?? "", "text", false, "Example: 12 or 12 km")}
                ${adminInput("Transfers", "transfers", routeData.transfers ?? 0)}
                ${adminInput("Route Tag", "tag", routeData.tag || "Available", "text", false, "Example: Direct, Cheapest, Popular, First-Time Friendly")}
                ${adminInput("Badge Class", "badge", routeData.badge || "badge-teal", "text", false, "Example: badge-teal, badge-amber, badge-fare, badge-success")}
                <div class="admin-editor-field">
                    <label for="adminRoute_status">Route Status</label>
                    <select id="adminRoute_status" name="status">
                        <option value="active" ${(routeData.status || "active") === "active" ? "selected" : ""}>Active</option>
                        <option value="inactive" ${(routeData.status || "active") === "inactive" ? "selected" : ""}>Inactive</option>
                    </select>
                    <small>Inactive routes are hidden from commuter view.</small>
                </div>
                ${adminInput("Schedule", "schedule", routeData.schedule || "", "text", true, "Example: Every 15 min • 6:00 AM - 10:00 PM")}

                ${adminTextarea("Stops", "stops", adminListToText(routeData.stops), true, "Put one stop per line.")}
                ${adminTextarea("Landmarks / Guide Cues", "landmarks", adminListToText(routeData.landmarks), true, "Put one landmark or instruction per line.")}
                ${adminTextarea("Recommended Because", "reason", routeData.reason || "", true)}
                ${adminTextarea("Walking Note", "walking", routeData.walking || "", true)}
                ${adminTextarea("Custom Guide Instructions", "instructions", routeData.instructions || "", true, "This appears in the route guide if provided.")}
                ${adminTextarea("Route Notes", "notes", routeData.notes || routeData.note || "", true, "This appears in the Route Notes section.")}
            </div>
        </form>
    `;

    const footerHTML = `
        <button type="button" class="btn btn-secondary" onclick="closeAdminEditor()">Cancel</button>
        <button type="button" class="btn btn-primary" onclick="saveAdminRouteEditor()">
            ${isEditing ? "Save Route Changes" : "Add Route"}
        </button>
    `;

    openAdminEditor(
        isEditing ? "Edit Complete Route Details" : "Add Complete Route",
        "Edit route name, company, schedule, time, fare, stops, landmarks, taglines, notes, and guide instructions.",
        bodyHTML,
        footerHTML
    );
}

function saveAdminRouteEditor() {
    if (!adminHasAccess()) {
        return;
    }

    const form = document.getElementById("adminRouteEditorForm");

    if (!form) {
        return;
    }

    const oldCategory = form.dataset.oldCategory;
    const routeId = form.dataset.routeId;
    const data = new FormData(form);

    const newCategory = String(data.get("category") || oldCategory || appState.currentCategory || "p2p");

    if (!routeDatabase[newCategory]) {
        routeDatabase[newCategory] = [];
    }

    let route = null;

    if (routeId && routeDatabase[oldCategory]) {
        route = routeDatabase[oldCategory].find(item => item.id === routeId);
    }

    const isNewRoute = !route;

    if (!route) {
        route = {
            id: `${newCategory}-${Date.now()}`
        };
    }

    const name = String(data.get("name") || "").trim();
    const transport = String(data.get("transport") || "").trim();
    const operator = String(data.get("operator") || "").trim();
    const origin = String(data.get("origin") || "").trim();
    const destination = String(data.get("destination") || "").trim();

    if (!name || !transport || !origin || !destination) {
        showToast("Route name, transport type, origin, and destination are required.");
        return;
    }

    route.name = name;
    route.title = name;
    route.route_name = name;

    route.transport = transport;
    route.operator = operator;
    route.company = operator;

    route.origin = origin;
    route.destination = destination;
    route.route = `${origin} → ${destination}`;
    route.direction = String(data.get("direction") || "").trim();

    route.fare = adminParseValue(data.get("fare"));
    route.time = adminParseValue(data.get("time"));
    route.travel_time = route.time;
    route.distance = adminParseValue(data.get("distance"));
    route.transfers = adminParseValue(data.get("transfers"));

    route.tag = String(data.get("tag") || "Available").trim();
    route.badge = String(data.get("badge") || "badge-teal").trim();
    route.schedule = String(data.get("schedule") || "No schedule").trim();

    route.stops = adminTextToList(data.get("stops"));
    route.landmarks = adminTextToList(data.get("landmarks"));

    if (route.stops.length === 0) {
        route.stops = [origin, destination];
    }

    if (route.landmarks.length === 0) {
        route.landmarks = ["No landmark instructions yet."];
    }

    route.reason = String(data.get("reason") || "").trim();
    route.walking = String(data.get("walking") || "").trim();
    route.instructions = String(data.get("instructions") || "").trim();
    route.notes = String(data.get("notes") || "").trim();
    route.note = route.notes;

    if (oldCategory !== newCategory && routeDatabase[oldCategory]) {
        routeDatabase[oldCategory] = routeDatabase[oldCategory].filter(item => item.id !== route.id);
    }

    if (isNewRoute || oldCategory !== newCategory) {
        routeDatabase[newCategory].push(route);
    }

    appState.currentCategory = newCategory;

    saveRouteDatabaseLocally();
    displayRoutesByCategory(newCategory);
    closeAdminEditor();

    showToast(isNewRoute ? "Route added successfully." : "Route updated successfully.");
}

function getAdminSiteTexts() {
    const defaults = {};

    adminSiteTextFields.forEach(field => {
        defaults[field.key] = field.defaultValue;
    });

    const savedTexts = JSON.parse(localStorage.getItem(ADMIN_SITE_TEXT_KEY) || "{}");

    return {
        ...defaults,
        ...savedTexts
    };
}

function applyAdminSiteTexts() {
    const texts = getAdminSiteTexts();

    adminSiteTextFields.forEach(field => {
        const elements = document.querySelectorAll(field.selector);

        elements.forEach(element => {
            element.textContent = texts[field.key];
        });
    });
}

function openAdminTextEditor() {
    if (!adminHasAccess()) {
        return;
    }

    const texts = getAdminSiteTexts();

    const fieldsHTML = adminSiteTextFields.map(field => {
        return `
            <div class="admin-editor-field full">
                <label for="adminText_${adminEscape(field.key)}">${adminEscape(field.label)}</label>
                <textarea 
                    id="adminText_${adminEscape(field.key)}" 
                    name="${adminEscape(field.key)}" 
                    rows="2"
                >${adminEscape(texts[field.key])}</textarea>
                <small>${adminEscape(field.selector)}</small>
            </div>
        `;
    }).join("");

    const bodyHTML = `
        <form id="adminTextEditorForm">
            <div class="admin-editor-grid">
                ${fieldsHTML}
            </div>
        </form>
    `;

    const footerHTML = `
        <button type="button" class="btn btn-secondary" onclick="resetAdminSiteTexts()">Reset Texts</button>
        <button type="button" class="btn btn-secondary" onclick="closeAdminEditor()">Cancel</button>
        <button type="button" class="btn btn-primary" onclick="saveAdminSiteTexts()">Save Text Changes</button>
    `;

    openAdminEditor(
        "Edit Texts and Taglines",
        "Edit the commuter-facing headings, subtitles, taglines, labels, and section texts.",
        bodyHTML,
        footerHTML
    );
}

function saveAdminSiteTexts() {
    if (!adminHasAccess()) {
        return;
    }

    const form = document.getElementById("adminTextEditorForm");

    if (!form) {
        return;
    }

    const data = new FormData(form);
    const updatedTexts = {};

    adminSiteTextFields.forEach(field => {
        updatedTexts[field.key] = String(data.get(field.key) || "").trim();
    });

    localStorage.setItem(ADMIN_SITE_TEXT_KEY, JSON.stringify(updatedTexts));

    applyAdminSiteTexts();
    closeAdminEditor();

    showToast("Website texts updated successfully.");
}

function resetAdminSiteTexts() {
    if (!adminHasAccess()) {
        return;
    }

    if (!confirm("Reset all website texts to default?")) {
        return;
    }

    localStorage.removeItem(ADMIN_SITE_TEXT_KEY);
    applyAdminSiteTexts();
    closeAdminEditor();

    showToast("Website texts reset successfully.");
}

function loadFareRulesLocally() {
    const savedRules = localStorage.getItem(ADMIN_FARE_RULES_KEY);

    if (!savedRules) {
        return;
    }

    const parsedRules = JSON.parse(savedRules);

    Object.keys(parsedRules).forEach(type => {
        if (fareData[type]) {
            fareData[type].baseFare = Number(parsedRules[type].baseFare);
            fareData[type].perKm = Number(parsedRules[type].perKm);
        }
    });
}

function saveFareRulesLocally() {
    localStorage.setItem(ADMIN_FARE_RULES_KEY, JSON.stringify(fareData));
}

function openAdminFareEditor() {
    if (!adminHasAccess()) {
        return;
    }

    const fieldsHTML = Object.keys(fareData).map(type => {
        return `
            <div class="admin-editor-field">
                <label for="fare_${adminEscape(type)}_base">Base Fare - ${adminEscape(type.toUpperCase())}</label>
                <input 
                    type="number" 
                    step="0.01" 
                    id="fare_${adminEscape(type)}_base" 
                    name="${adminEscape(type)}_baseFare" 
                    value="${adminEscape(fareData[type].baseFare)}"
                >
            </div>

            <div class="admin-editor-field">
                <label for="fare_${adminEscape(type)}_perKm">Per KM - ${adminEscape(type.toUpperCase())}</label>
                <input 
                    type="number" 
                    step="0.01" 
                    id="fare_${adminEscape(type)}_perKm" 
                    name="${adminEscape(type)}_perKm" 
                    value="${adminEscape(fareData[type].perKm)}"
                >
            </div>
        `;
    }).join("");

    const bodyHTML = `
        <form id="adminFareEditorForm">
            <div class="admin-editor-grid">
                ${fieldsHTML}
            </div>
        </form>
    `;

    const footerHTML = `
        <button type="button" class="btn btn-secondary" onclick="closeAdminEditor()">Cancel</button>
        <button type="button" class="btn btn-primary" onclick="saveAdminFareRules()">Save Fare Rules</button>
    `;

    openAdminEditor(
        "Edit Fare Calculator Rules",
        "Edit the base fare and per-kilometer cost used by the fare calculator.",
        bodyHTML,
        footerHTML
    );
}

function saveAdminFareRules() {
    if (!adminHasAccess()) {
        return;
    }

    const form = document.getElementById("adminFareEditorForm");

    if (!form) {
        return;
    }

    const data = new FormData(form);

    Object.keys(fareData).forEach(type => {
        const baseFare = Number(data.get(`${type}_baseFare`));
        const perKm = Number(data.get(`${type}_perKm`));

        if (!Number.isNaN(baseFare)) {
            fareData[type].baseFare = baseFare;
        }

        if (!Number.isNaN(perKm)) {
            fareData[type].perKm = perKm;
        }
    });

    saveFareRulesLocally();
    updateFareInfo();
    closeAdminEditor();

    showToast("Fare rules updated successfully.");
}

function ensureAdminModeButtons() {
    const adminModeBar = document.getElementById("adminModeBar");

    if (!adminModeBar) {
        return;
    }

    let actions = adminModeBar.querySelector(".admin-mode-actions");

    if (!actions) {
        actions = document.createElement("div");
        actions.className = "admin-mode-actions";
        adminModeBar.appendChild(actions);
    }

    if (!document.getElementById("editSiteTextsButton")) {
        const editTextsButton = document.createElement("button");
        editTextsButton.type = "button";
        editTextsButton.id = "editSiteTextsButton";
        editTextsButton.className = "btn btn-secondary btn-sm";
        editTextsButton.textContent = "Edit Texts";
        editTextsButton.onclick = openAdminTextEditor;
        actions.insertBefore(editTextsButton, actions.firstChild);
    }

    if (!document.getElementById("editFareRulesButton")) {
        const editFareButton = document.createElement("button");
        editFareButton.type = "button";
        editFareButton.id = "editFareRulesButton";
        editFareButton.className = "btn btn-secondary btn-sm";
        editFareButton.textContent = "Edit Fare Rules";
        editFareButton.onclick = openAdminFareEditor;
        actions.insertBefore(editFareButton, actions.firstChild);
    }
}

function toggleAddAdminPanel() {
    const panel = document.getElementById("addAdminPanel");

    if (!panel) {
        return;
    }

    panel.style.display = panel.style.display === "none" ? "block" : "none";
}

function saveRouteDatabaseLocally() {
    localStorage.setItem("biyahero_route_database", JSON.stringify(routeDatabase));
}

function loadRouteDatabaseLocally() {
    const savedRoutes = localStorage.getItem("biyahero_route_database");

    if (!savedRoutes) {
        return;
    }

    const parsedRoutes = JSON.parse(savedRoutes);

    Object.keys(parsedRoutes).forEach(category => {
        routeDatabase[category] = parsedRoutes[category];
    });
}

// ============================================
// ENHANCED ROUTE GUIDE STEPS
// Uses admin-edited stops, landmarks, instructions,
// and route notes.
// ============================================

function generateSakaySteps(route) {
    const stops = Array.isArray(route.stops) && route.stops.length > 0
        ? route.stops
        : [route.origin || "Origin", route.destination || "Destination"];

    const landmarks = Array.isArray(route.landmarks) && route.landmarks.length > 0
        ? route.landmarks
        : ["Ask staff or passengers to confirm the correct stop."];

    const steps = [];

    steps.push({
        label: "01",
        title: "Go to Boarding Area",
        detail: `Head to ${route.origin || "the terminal"}.`,
        landmark: landmarks[0] || "Near the main entrance of Market! Market! mall"
    });

    steps.push({
        label: "02",
        title: `Board ${route.transport || "Vehicle"}`,
        detail: `Look for the ${route.transport || "vehicle"} bound for ${route.destination || "your destination"}.`,
        landmark: route.operator ? `Operator / Company: ${route.operator}` : "Ask staff for the correct boarding bay."
    });

    stops.forEach((stop, index) => {
        if (index === 0 || index === stops.length - 1) {
            return;
        }

        steps.push({
            label: String(steps.length + 1).padStart(2, "0"),
            title: `Pass by ${stop}`,
            detail: `Stay alert as the route passes ${stop}.`,
            landmark: landmarks[index] || "Use this as a route checkpoint."
        });
    });

    steps.push({
        label: String(steps.length + 1).padStart(2, "0"),
        title: "Pay Fare",
        detail: `Prepare ₱${route.fare || "TBD"} for the fare.`,
        landmark: route.schedule ? `Schedule: ${route.schedule}` : "Usually collected before or during the trip."
    });

    steps.push({
        label: String(steps.length + 1).padStart(2, "0"),
        title: "Get Off",
        detail: `Signal the driver before your stop at ${route.destination || "your destination"}.`,
        landmark: landmarks[landmarks.length - 1] || "Ask other passengers or the conductor to confirm the stop."
    });

    if (route.instructions) {
        steps.push({
            label: String(steps.length + 1).padStart(2, "0"),
            title: "Extra Admin Guide",
            detail: route.instructions,
            landmark: route.walking || "Follow the added admin instruction."
        });
    }

    return steps.map(step => `
        <div class="step">
            <div class="step-content">
                <div class="step-header">
                    <span class="step-count">${adminEscape(step.label)}</span>
                    <p class="step-title">${adminEscape(step.title)}</p>
                </div>

                <p class="step-detail">${adminEscape(step.detail)}</p>
                <p class="step-landmark">
                    <span class="step-landmark-label">Landmark:</span> ${adminEscape(step.landmark)}
                </p>
            </div>
        </div>
    `).join("");
}

// ============================================
// ENHANCED ROUTE DETAIL DISPLAY
// ============================================

// ============================================
// ADMIN INITIALIZATION
// ============================================

document.addEventListener("DOMContentLoaded", function () {
    ensureAdminEditorStyles();
    ensureAdminEditorModal();
    ensureAdminModeButtons();

    loadFareRulesLocally();
    applyAdminSiteTexts();

    if (typeof updateFareInfo === "function") {
        updateFareInfo();
    }
});

/* =========================================================
   BIYAHERO PRIORITY SYSTEM UPDATE
   - MySQL route loading
   - Admin route add/edit/delete through PHP
   - Functional global search
   - Admin command-bar/logout reset
   - Toast notifications instead of alert boxes
   - Offline access UI removed
========================================================= */

const BIYAHERO_ROUTE_CATEGORIES = ["p2p", "uv", "jeepney", "bus", "ejeep"];
let globalSearchTimer = null;

function showToast(message, type = "info") {
    const text = String(message || "Something happened.");
    let container = document.getElementById("toastContainer");

    if (!container) {
        container = document.createElement("div");
        container.id = "toastContainer";
        container.className = "toast-container";
        document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.className = `toast-message toast-${type}`;
    toast.setAttribute("role", "status");
    toast.innerHTML = `
        <span class="toast-dot" aria-hidden="true"></span>
        <span class="toast-text">${adminEscape(text)}</span>
        <button type="button" class="toast-close" aria-label="Close notification">×</button>
    `;

    toast.querySelector(".toast-close").addEventListener("click", () => {
        toast.classList.add("is-leaving");
        setTimeout(() => toast.remove(), 180);
    });

    container.appendChild(toast);

    requestAnimationFrame(() => {
        toast.classList.add("is-visible");
    });

    setTimeout(() => {
        toast.classList.add("is-leaving");
        setTimeout(() => toast.remove(), 220);
    }, 3600);
}

function normalizeRouteForClient(route) {
    if (!route) {
        return null;
    }

    const id = route.id || route.route_id || "";
    const name = route.name || route.route_name || route.title || "Unnamed Route";
    const origin = route.origin || "Market! Market!";
    const destination = route.destination || "Destination";
    const time = route.time ?? route.travel_time ?? "";

    return {
        ...route,
        id: String(id),
        route_id: route.route_id || id,
        name: name,
        title: name,
        route_name: name,
        origin: origin,
        destination: destination,
        route: route.route || `${origin} → ${destination}`,
        time: time,
        travel_time: time,
        category: route.category || appState.currentCategory || "p2p",
        operator: route.operator || route.company || "",
        company: route.company || route.operator || "",
        transfers: route.transfers ?? 0,
        tag: route.tag || "Available",
        badge: route.badge || "badge-teal",
        stops: Array.isArray(route.stops) ? route.stops : adminTextToList(route.stops || `${origin}\n${destination}`),
        landmarks: Array.isArray(route.landmarks) ? route.landmarks : adminTextToList(route.landmarks || "")
    };
}

function mergeFetchedRoutes(routes) {
    if (!Array.isArray(routes)) {
        return;
    }

    routes.forEach(item => {
        const route = normalizeRouteForClient(item);
        if (!route) {
            return;
        }

        const category = route.category || "p2p";

        if (!routeDatabase[category]) {
            routeDatabase[category] = [];
        }

        const existingIndex = routeDatabase[category].findIndex(saved => String(saved.id) === String(route.id));

        if (existingIndex >= 0) {
            routeDatabase[category][existingIndex] = route;
        } else {
            routeDatabase[category].push(route);
        }
    });
}

function renderRouteCards(container, routes, category, options = {}) {
    container.innerHTML = "";

    if (!routes || routes.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-mark" aria-hidden="true">R</div>
                <p class="empty-title">${options.search ? "No matching routes" : "No routes found"}</p>
                <p class="empty-text">${options.search ? "Try another route, terminal, fare, or transport type." : "Ask an admin to add routes for this transport type."}</p>
            </div>
        `;
        return;
    }

    routes.forEach(rawRoute => {
        const route = normalizeRouteForClient(rawRoute);
        const routeCategory = route.category || category || "p2p";
        const card = document.createElement("div");
        card.className = "route-card premium-route-card";

        card.addEventListener("click", () => openRouteDetail(route));

        const statusBadge = appState.isAdmin && route.status
            ? `<span class="badge ${route.status === "active" ? "badge-success" : "badge-warning"}">${adminEscape(route.status)}</span>`
            : "";

        const adminControls = appState.isAdmin
            ? `
                <div class="admin-route-actions">
                    <button 
                        type="button" 
                        class="btn btn-secondary btn-sm"
                        onclick="event.stopPropagation(); editRouteAdmin('${adminEscape(routeCategory)}', '${adminEscape(route.id)}')">
                        Edit
                    </button>

                    <button 
                        type="button" 
                        class="btn btn-secondary btn-sm admin-danger-btn"
                        onclick="event.stopPropagation(); deleteRouteAdmin('${adminEscape(routeCategory)}', '${adminEscape(route.id)}')">
                        Delete
                    </button>
                </div>
            `
            : "";

        card.innerHTML = `
            <div class="route-header">
                <div>
                    <h4 class="route-title">${adminEscape(route.name)}</h4>
                    <p class="route-summary">${adminEscape(route.operator || route.direction || route.route || "")}</p>
                </div>

                <div class="route-card-badges">
                    ${statusBadge}
                    <span class="badge badge-teal">${adminEscape(route.tag || "Available")}</span>
                </div>
            </div>

            <div class="route-details">
                <div class="route-detail-item">
                    <span class="route-detail-label">Fare</span>
                    <span class="route-detail-value fare">₱${adminEscape(route.fare ?? "TBD")}</span>
                </div>

                <div class="route-detail-item">
                    <span class="route-detail-label">Time</span>
                    <span class="route-detail-value">${adminEscape(formatRouteTime(route.time || route.travel_time))}</span>
                </div>

                <div class="route-detail-item">
                    <span class="route-detail-label">Distance</span>
                    <span class="route-detail-value">${adminEscape(route.distance || "N/A")}${typeof route.distance === "number" ? " km" : ""}</span>
                </div>

                <div class="route-detail-item">
                    <span class="route-detail-label">Transport</span>
                    <span class="route-detail-value">${adminEscape(route.transport || "N/A")}</span>
                </div>
            </div>

            <div class="route-detail-item" style="margin-top: var(--spacing-base);">
                <span class="route-detail-label">Schedule</span>
                <span class="route-detail-value">${adminEscape(route.schedule || "No schedule")}</span>
            </div>

            <p class="route-card-note" style="margin: var(--spacing-base) 0 0 0;">
                ${options.search ? `Matched under ${adminEscape((route.category || "route").toUpperCase())}.` : "Student, Senior Citizen, and PWD discounts may apply."}
            </p>

            ${adminControls}
        `;

        container.appendChild(card);
    });
}

function displayRoutesByCategory(category, options = {}) {
    const container = document.getElementById("routesList");

    if (!container) {
        return;
    }

    const isSearch = Boolean(options.search);
    const selectedCategory = category || appState.currentCategory || "p2p";

    if (!isSearch) {
        appState.currentCategory = selectedCategory;
    }

    container.innerHTML = `
        <div class="empty-state route-loading-state">
            <div class="empty-mark" aria-hidden="true">B</div>
            <p class="empty-title">Loading routes...</p>
            <p class="empty-text">Getting the latest routes from MySQL.</p>
        </div>
    `;

    const params = new URLSearchParams();

    if (!isSearch && selectedCategory) {
        params.set("category", selectedCategory);
    }

    if (isSearch) {
        params.set("search", options.search);
    }

    fetch(`get_routes.php?${params.toString()}`, {
        credentials: "same-origin"
    })
        .then(response => response.json())
        .then(data => {
            if (data.status !== "success") {
                throw new Error(data.message || "Unable to load routes.");
            }

            const routes = (data.routes || []).map(normalizeRouteForClient).filter(Boolean);
            mergeFetchedRoutes(routes);

            if (!isSearch && selectedCategory) {
                routeDatabase[selectedCategory] = routes;
            }

            renderRouteCards(container, routes, selectedCategory, options);
        })
        .catch(error => {
            console.error("Route loading failed:", error);
            const fallbackRoutes = isSearch
                ? Object.values(routeDatabase).flat().filter(route => routeMatchesSearch(route, options.search))
                : (routeDatabase[selectedCategory] || []);

            renderRouteCards(container, fallbackRoutes, selectedCategory, options);
            showToast("Could not connect to get_routes.php. Showing local route data instead.", "warning");
        });
}

function routeMatchesSearch(route, query) {
    const needle = String(query || "").toLowerCase().trim();

    if (!needle) {
        return true;
    }

    const haystack = [
        route.name,
        route.route_name,
        route.origin,
        route.destination,
        route.transport,
        route.operator,
        route.company,
        route.schedule,
        route.tag,
        route.fare,
        route.category
    ].join(" ").toLowerCase();

    return haystack.includes(needle);
}

function setupGlobalSearch() {
    const input = document.getElementById("globalSearchInput");

    if (!input) {
        return;
    }

    input.addEventListener("input", () => {
        window.clearTimeout(globalSearchTimer);

        globalSearchTimer = window.setTimeout(() => {
            handleGlobalSearchInput(input.value);
        }, 220);
    });

    input.addEventListener("keydown", event => {
        if (event.key === "Enter") {
            event.preventDefault();
            handleGlobalSearchInput(input.value);
        }
    });
}

function handleGlobalSearchInput(value) {
    const query = String(value || "").trim();

    navigateScreen(
        "routesScreen",
        document.querySelector('.topbar-nav [data-screen="routesScreen"]')
    );

    if (!query) {
        displayRoutesByCategory(appState.currentCategory || "p2p");
        return;
    }

    document.querySelectorAll(".tab").forEach(tab => tab.classList.remove("active"));
    displayRoutesByCategory("search", { search: query });
}

// ============================================
// TRACKER COUNTS
// ============================================
function updateTrackerCounts(savedCount = null) {
    const recentSearches = JSON.parse(localStorage.getItem("biyahero_recent_searches")) || [];

    const recentSearchesCount = document.getElementById("recentSearchesCount");
    const savedRoutesCount = document.getElementById("savedRoutesCount");

    if (recentSearchesCount) {
        recentSearchesCount.textContent = recentSearches.length;
    }

    if (savedRoutesCount && savedCount !== null) {
        savedRoutesCount.textContent = savedCount;
    }
}

function findRoutes() {
    const origin = document.getElementById("searchOrigin").value.trim();
    const destination = document.getElementById("searchDestination").value.trim();

    if (!origin || !destination) {
        showToast("Please enter both origin and destination.", "warning");
        return;
    }

    saveRecentSearch(origin, destination);

    const emptyState = document.getElementById("emptyState");
    const resultsContainer = document.getElementById("resultsContainer");

    if (emptyState) {
        emptyState.style.display = "none";
    }

    if (resultsContainer) {
        resultsContainer.style.display = "flex";
    }

    const results = generateRouteResults(origin, destination);
    displayRouteResults(results);
}

function saveRoute() {
    if (!currentRoute) {
        showToast("No route selected.", "warning");
        return;
    }

    const routeName = currentRoute.route_name || currentRoute.name || currentRoute.title || currentRoute.route || "Unnamed Route";

    const origin =
        currentRoute.origin ||
        (currentRoute.route ? currentRoute.route.split("→")[0].trim() : "") ||
        (routeName.includes("→") ? routeName.split("→")[0].trim() : "Unknown Origin");

    const destination =
        currentRoute.destination ||
        (currentRoute.route ? currentRoute.route.split("→")[1]?.trim() : "") ||
        (routeName.includes("→") ? routeName.split("→")[1]?.trim() : "Unknown Destination");

    const transport = currentRoute.transport || "Unknown";
    const fare = currentRoute.fare || 0;
    const travelTime = formatRouteTime(currentRoute.travel_time || currentRoute.time);

    const formData = new FormData();
    formData.append("route_name", routeName);
    formData.append("origin", origin);
    formData.append("destination", destination);
    formData.append("transport", transport);
    formData.append("fare", fare);
    formData.append("travel_time", travelTime);

    fetch("save_route.php", {
        method: "POST",
        body: formData,
        credentials: "same-origin"
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                showToast("Route saved successfully.", "success");
                getSavedRoutes();
                closeRouteDetail();
            } else if (data.status === "exists") {
                showToast(data.message || "This route is already saved.", "warning");
            } else {
                showToast(data.message || "Failed to save route.", "error");
            }
        })
        .catch(error => {
            console.error("Error:", error);
            showToast("Something went wrong while saving the route.", "error");
        });
}

function deleteSavedRoute(savedId) {
    if (!confirm("Remove this saved route?")) {
        return;
    }

    const formData = new FormData();
    formData.append("saved_id", savedId);

    fetch("delete_saved_route.php", {
        method: "POST",
        body: formData,
        credentials: "same-origin"
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                showToast("Saved route removed.", "success");
                getSavedRoutes();
            } else {
                showToast(data.message || "Failed to remove saved route.", "error");
            }
        })
        .catch(error => {
            console.error("Error:", error);
            showToast("Something went wrong while removing the saved route.", "error");
        });
}

function registerUser() {
    const fullName = document.getElementById("registerName").value.trim();
    const age = document.getElementById("registerAge").value.trim();
    const username = document.getElementById("registerUsername").value.trim();
    const password = document.getElementById("registerPassword").value;

    if (!fullName || !age || !username || !password) {
        showToast("Please fill in all fields.", "warning");
        return;
    }

    const formData = new FormData();
    formData.append("full_name", fullName);
    formData.append("age", age);
    formData.append("username", username);
    formData.append("password", password);

    fetch("register.php", {
        method: "POST",
        body: formData,
        credentials: "same-origin"
    })
        .then(response => response.json())
        .then(data => {
            const result = data.status;

            if (result === "success") {
                showToast(data.message || "Account created successfully.", "success");
                toggleAuthForm();
            } else if (result === "duplicate") {
                showToast(data.message || "Username already exists.", "warning");
            } else if (result === "empty") {
                showToast(data.message || "Please complete all fields.", "warning");
            } else {
                showToast(data.message || "Registration failed.", "error");
            }
        })
        .catch(error => {
            console.log(error);
            showToast("Error connecting to register.php.", "error");
        });
}

function loginUser() {
    const username = document.getElementById("loginUsername").value.trim();
    const password = document.getElementById("loginPassword").value;

    if (!username || !password) {
        showToast("Please enter your username and password.", "warning");
        return;
    }

    const formData = new FormData();
    formData.append("username", username);
    formData.append("password", password);

    fetch("login.php", {
        method: "POST",
        body: formData,
        credentials: "same-origin"
    })
        .then(response => response.json())
        .then(data => {
            const result = data.status;
            const role = data.role;

            if (result === "success" && role === "head_admin") {
                showToast("Head admin login successful.", "success");
                navigateToHome();
                enableAdminMode("head_admin");
                loadLoggedInUser();
            } else if (result === "success" && role === "admin") {
                showToast("Admin login successful.", "success");
                navigateToHome();
                enableAdminMode("admin");
                loadLoggedInUser();
            } else if (result === "success" && role === "commuter") {
                showToast("Login successful.", "success");
                navigateToHome();
                enableAdminMode("commuter");
                loadLoggedInUser();
            } else if (result === "empty") {
                showToast("Please complete all fields.", "warning");
            } else if (result === "wrong_password") {
                showToast("Incorrect password.", "error");
            } else if (result === "user_not_found") {
                showToast("Username not found.", "error");
            } else {
                showToast(data.message || "Login failed.", "error");
            }
        })
        .catch(error => {
            console.log(error);
            showToast("Error connecting to login.php.", "error");
        });
}

function resetAdminUiState() {
    const appContainer = document.querySelector(".app-container");
    const adminModeBar = document.getElementById("adminModeBar");
    const addAdminPanel = document.getElementById("addAdminPanel");
    const addAdminButton = document.getElementById("addAdminButton");
    const editTextsButton = document.getElementById("editSiteTextsButton");
    const editFareButton = document.getElementById("editFareRulesButton");
    const adminEditorOverlay = document.getElementById("adminEditorOverlay");

    appState.isAdmin = false;
    appState.isHeadAdmin = false;

    if (appContainer) {
        appContainer.classList.remove("is-admin", "is-head-admin");
    }

    [adminModeBar, addAdminPanel, addAdminButton, editTextsButton, editFareButton].forEach(element => {
        if (element) {
            element.style.display = "none";
        }
    });

    if (adminEditorOverlay) {
        adminEditorOverlay.classList.remove("is-open");
    }
}

function logoutUser() {
    fetch("logout.php", {
        method: "POST",
        credentials: "same-origin"
    })
        .then(response => response.json())
        .then(data => {
            const result = data.status;

            if (result === "success") {
                showToast(data.message || "You have been logged out.", "success");

                const appContainer = document.querySelector(".app-container");
                resetAdminUiState();

                if (appContainer) {
                    appContainer.classList.remove("is-authenticated");
                }

                document.querySelectorAll(".screen").forEach(screen => {
                    screen.classList.remove("active");
                });

                const authScreen = document.getElementById("authScreen");
                const loginForm = document.getElementById("loginForm");
                const registerForm = document.getElementById("registerForm");
                const loginUsername = document.getElementById("loginUsername");
                const loginPassword = document.getElementById("loginPassword");
                const topbarUserName = document.getElementById("topbarUserName");
                const userInitials = document.getElementById("userInitials");

                if (authScreen) {
                    authScreen.classList.add("active");
                }

                if (loginForm) {
                    loginForm.style.display = "flex";
                }

                if (registerForm) {
                    registerForm.style.display = "none";
                }

                if (loginUsername) {
                    loginUsername.value = "";
                }

                if (loginPassword) {
                    loginPassword.value = "";
                }

                if (topbarUserName) {
                    topbarUserName.textContent = "User";
                }

                if (userInitials) {
                    userInitials.textContent = "U";
                }

                document.querySelectorAll(".nav-item").forEach(item => item.classList.remove("active"));

                const homeNav = document.querySelector('.topbar-nav [data-screen="homeScreen"]');

                if (homeNav) {
                    homeNav.classList.add("active");
                }

                appState.currentScreen = "authScreen";
                currentRoute = null;
                appState.selectedRoute = null;
            } else {
                showToast(data.message || "Logout failed.", "error");
            }
        })
        .catch(error => {
            console.log(error);
            showToast("Error connecting to logout.php.", "error");
        });
}

function adminHasAccess() {
    if (!appState.isAdmin) {
        showToast("Only admins can use this feature.", "warning");
        return false;
    }

    return true;
}

function enableAdminMode(role) {
    appState.isAdmin = role === "admin" || role === "head_admin";
    appState.isHeadAdmin = role === "head_admin";

    const appContainer = document.querySelector(".app-container");
    const adminModeBar = document.getElementById("adminModeBar");
    const addAdminButton = document.getElementById("addAdminButton");
    const addAdminPanel = document.getElementById("addAdminPanel");

    if (appContainer) {
        appContainer.classList.toggle("is-admin", appState.isAdmin);
        appContainer.classList.toggle("is-head-admin", appState.isHeadAdmin);
    }

    if (adminModeBar) {
        adminModeBar.style.display = appState.isAdmin ? "flex" : "none";
    }

    if (addAdminButton) {
        addAdminButton.style.display = appState.isHeadAdmin ? "inline-flex" : "none";
    }

    if (!appState.isHeadAdmin && addAdminPanel) {
        addAdminPanel.style.display = "none";
    }

    ensureAdminModeButtons();

    const editTextsButton = document.getElementById("editSiteTextsButton");
    const editFareButton = document.getElementById("editFareRulesButton");

    if (editTextsButton) {
        editTextsButton.style.display = appState.isAdmin ? "inline-flex" : "none";
    }

    if (editFareButton) {
        editFareButton.style.display = appState.isAdmin ? "inline-flex" : "none";
    }

    applyAdminSiteTexts();
    displayRoutesByCategory(appState.currentCategory || "p2p");
}

function loadLoggedInUser() {
    fetch("check_session.php", {
        credentials: "same-origin"
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === "logged_in") {
                const firstName = data.first_name || "User";
                const role = data.role || "commuter";
                const topbarUserName = document.getElementById("topbarUserName");
                const userInitials = document.getElementById("userInitials");

                if (topbarUserName) {
                    topbarUserName.textContent = firstName;
                }

                if (userInitials) {
                    userInitials.textContent = firstName.charAt(0).toUpperCase();
                }

                const appContainer = document.querySelector(".app-container");
                const authScreenIsActive = document.getElementById("authScreen")?.classList.contains("active");

                if (appContainer && authScreenIsActive) {
                    navigateToHome();
                }

                enableAdminMode(role);
            } else {
                resetAdminUiState();
            }
        })
        .catch(error => {
            console.error("Error loading user:", error);
        });
}

function saveAdminRouteEditor() {
    if (!adminHasAccess()) {
        return;
    }

    const form = document.getElementById("adminRouteEditorForm");

    if (!form) {
        return;
    }

    const data = new FormData(form);
    const routeId = String(form.dataset.routeId || "").trim();
    const name = String(data.get("name") || "").trim();
    const transport = String(data.get("transport") || "").trim();
    const origin = String(data.get("origin") || "").trim();
    const destination = String(data.get("destination") || "").trim();
    const newCategory = String(data.get("category") || appState.currentCategory || "p2p").trim();
    const isNewRoute = !routeId;

    if (!name || !transport || !origin || !destination) {
        showToast("Route name, transport type, origin, and destination are required.", "warning");
        return;
    }

    const payload = new FormData();

    data.forEach((value, key) => {
        payload.append(key, value);
    });

    payload.set("route_id", routeId);
    payload.set("route_name", name);
    payload.set("travel_time", String(data.get("time") || ""));
    payload.set("operator", String(data.get("operator") || ""));
    payload.set("status", String(data.get("status") || "active"));
    payload.set("ajax", "1");

    fetch("save_route_admin.php", {
        method: "POST",
        body: payload,
        credentials: "same-origin",
        headers: {
            "X-Requested-With": "XMLHttpRequest"
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                showToast(isNewRoute ? "Route added successfully." : "Route updated successfully.", "success");
                appState.currentCategory = newCategory;
                closeAdminEditor();
                displayRoutesByCategory(newCategory);
            } else {
                showToast(data.message || "Failed to save route.", "error");
            }
        })
        .catch(error => {
            console.error("Admin route save failed:", error);
            showToast("Error connecting to save_route_admin.php.", "error");
        });
}

function deleteRouteAdmin(category, routeId) {
    if (!adminHasAccess()) {
        return;
    }

    if (!confirm("Delete this route?")) {
        return;
    }

    const payload = new FormData();
    payload.append("route_id", routeId);
    payload.append("id", routeId);
    payload.append("ajax", "1");

    fetch("delete_route_admin.php", {
        method: "POST",
        body: payload,
        credentials: "same-origin",
        headers: {
            "X-Requested-With": "XMLHttpRequest"
        }
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                showToast("Route deleted successfully.", "success");

                if (routeDatabase[category]) {
                    routeDatabase[category] = routeDatabase[category].filter(route => String(route.id) !== String(routeId));
                }

                displayRoutesByCategory(category || appState.currentCategory || "p2p");
            } else {
                showToast(data.message || "Failed to delete route.", "error");
            }
        })
        .catch(error => {
            console.error("Admin route delete failed:", error);
            showToast("Error connecting to delete_route_admin.php.", "error");
        });
}

function openRouteDetail(routeData) {
    currentRoute = normalizeRouteForClient(routeData);
    appState.selectedRoute = currentRoute;

    const detailScreen = document.getElementById("routeDetailScreen");
    const content = document.getElementById("routeDetailContent");
    const pageTitle = document.getElementById("routeDetailPageTitle");
    const pageSubtitle = document.getElementById("routeDetailPageSubtitle");

    if (!detailScreen || !content || !pageTitle || !pageSubtitle) {
        return;
    }

    const route = currentRoute;
    const stepsHTML = generateSakaySteps(route);
    const routeTitle = route.title || route.name || route.route_name || "Route Details";
    const routeSubtitle = route.route || `${route.origin || "Origin"} → ${route.destination || "Destination"}`;
    const timeText = formatRouteTime(route.time || route.travel_time);

    const routeNotes = route.notes || route.note || `
        Have small change ready for fares.
        Signal the driver before you get off.
        Peak hours are usually 7-9 AM and 5-7 PM.
        Ask other passengers for stop confirmations.
    `;

    const routeNotesHTML = adminTextToList(routeNotes)
        .map(note => `<li>${adminEscape(note)}</li>`)
        .join("");

    appState.previousScreen = appState.currentScreen && appState.currentScreen !== "routeDetailScreen"
        ? appState.currentScreen
        : appState.previousScreen || "homeScreen";

    pageTitle.textContent = routeTitle;
    pageSubtitle.textContent = `${route.transport || "Transport"} • ${routeSubtitle}`;

    content.innerHTML = `
        <div class="route-detail-intelligence-grid">
            <div class="route-focus-banner">
                <div class="route-focus-header">
                    <div>
                        <h3 class="route-focus-title">${adminEscape(routeTitle)}</h3>
                        <p class="route-focus-subtitle">${adminEscape(routeSubtitle)}</p>
                    </div>

                    <span class="badge ${adminEscape(route.badge || "badge-teal")}" style="color: var(--text-inverse); background: rgba(255,255,255,0.2);">
                        ${adminEscape(route.tag || "Guide")}
                    </span>
                </div>

                <div class="route-quick-stats">
                    <div class="route-quick-stat">
                        <p class="route-quick-label">Total Fare</p>
                        <p class="route-quick-value">₱${adminEscape(route.fare || "TBD")}</p>
                    </div>

                    <div class="route-quick-stat">
                        <p class="route-quick-label">Travel Time</p>
                        <p class="route-quick-value">${adminEscape(timeText)}</p>
                    </div>

                    <div class="route-quick-stat">
                        <p class="route-quick-label">Transfers</p>
                        <p class="route-quick-value">${adminEscape(route.transfers || 0)}</p>
                    </div>
                </div>
            </div>

            <aside class="insight-panel tone-guide" aria-label="BiyaHero Guide intelligence">
                <div class="insight-orb" aria-hidden="true"></div>

                <h3>Instructions built for real commute moments.</h3>
                <p>The guide keeps boarding, fare payment, landmarks, and final stop cues separated so the route feels easy to follow.</p>

                <div class="insight-stack">
                    <div class="insight-item">
                        <span>Boarding clarity</span>
                        <strong>${adminEscape(route.origin || "Terminal-ready")}</strong>
                    </div>

                    <div class="insight-item">
                        <span>Company</span>
                        <strong>${adminEscape(route.operator || route.company || "Not specified")}</strong>
                    </div>

                    <div class="insight-item">
                        <span>Schedule</span>
                        <strong>${adminEscape(route.schedule || "No schedule")}</strong>
                    </div>
                </div>
            </aside>
        </div>

        <div class="route-detail-card">
            <h4>Route Map</h4>

            <div class="map-placeholder">
                <div class="map-placeholder-content">
                    <div class="map-symbol" aria-hidden="true"></div>
                    <p style="margin: 0; font-size: var(--font-size-sm);">Interactive route map</p>
                    <p style="margin: var(--spacing-xs) 0 0 0; font-size: var(--font-size-xs);">
                        ${adminEscape(route.origin || "Start")} → ${adminEscape(route.destination || "Destination")}
                    </p>
                </div>
            </div>
        </div>

        <div class="route-detail-card">
            <h4>Trip Instructions</h4>
            <div class="stepper">
                ${stepsHTML}
            </div>
        </div>

        <div class="route-detail-card">
            <h4>Taglish Voice Guidance</h4>

            <div class="toggle" id="voiceToggle" onclick="toggleVoiceGuide()">
                <div class="toggle-label">
                    <p class="toggle-title">Enable Voice Guidance</p>
                    <p class="toggle-subtitle">Get step-by-step instructions in Taglish</p>
                </div>

                <div class="toggle-switch"></div>
            </div>

            <div id="voicePreview" style="display: none; margin-top: var(--spacing-lg); background: var(--bg-surface-subtle); padding: var(--spacing-lg); border-radius: var(--radius-lg); border-left: 4px solid var(--route-500);">
                <p style="margin: 0 0 var(--spacing-base) 0; font-weight: var(--font-weight-semibold); color: var(--text-brand);">Sample Voice Guidance:</p>
                <p style="margin: 0; font-style: italic; color: var(--text-secondary);">
                    "Magmula sa ${adminEscape(route.origin || "Market Market")}, sakay sa ${adminEscape(route.transport || "vehicle")} papunta sa ${adminEscape(route.destination || "destination mo")}. Bumaba kapag malapit ka na sa landmark. Salamat sa paggamit ng BiyaHero!"
                </p>
            </div>
        </div>

        <div class="route-guide-actions">
            <button type="button" class="btn btn-secondary" onclick="saveRoute()">
                Save Route
            </button>

            <button type="button" class="btn btn-secondary">
                Share Route
            </button>
        </div>

        <div class="route-detail-card" style="background: var(--bg-surface-subtle);">
            <h4 style="margin-bottom: var(--spacing-base);">Route Notes</h4>

            <ul class="route-note-list">
                ${routeNotesHTML}
            </ul>
        </div>
    `;

    document.querySelectorAll(".screen").forEach(screen => {
        screen.classList.remove("active");
    });

    detailScreen.classList.add("active");
    appState.currentScreen = "routeDetailScreen";

    detailScreen.scrollTo({
        top: 0,
        behavior: "smooth"
    });

    applyAdminSiteTexts();
}

// Remove any offline editable text definitions that may exist in older copies.
for (let index = adminSiteTextFields.length - 1; index >= 0; index--) {
    if (["offlineRoutesKicker", "offlineRoutesTitle"].includes(adminSiteTextFields[index].key)) {
        adminSiteTextFields.splice(index, 1);
    }
}

document.addEventListener("DOMContentLoaded", function () {
    setupGlobalSearch();
    displayRecentSearches();
    updateTrackerCounts();
    loadLoggedInUser();

    if (!document.querySelector(".app-container")?.classList.contains("is-authenticated")) {
        resetAdminUiState();
    }
});
