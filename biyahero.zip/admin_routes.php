<?php
session_start();
include "db.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: index.html");
    exit();
}

if ($_SESSION["role"] !== "admin" && $_SESSION["role"] !== "head_admin") {
    header("Location: index.html");
    exit();
}

$routes = $conn->query("SELECT * FROM routes ORDER BY category, route_name");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Routes</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="app-container is-authenticated">
    <main class="screen active" style="padding: 30px;">

        <div class="section-header enhanced-section-header">
            <div>
                <span class="section-kicker">Admin View</span>
                <h2>Manage Routes</h2>
            </div>
        </div>

        <div class="intelligence-surface" style="margin-bottom: 24px;">
            <h3>Add New Route</h3>

            <form action="save_route_admin.php" method="POST">
                <input type="hidden" name="route_id" value="">

                <input type="text" name="route_name" placeholder="Route Name" required>
                <input type="text" name="category" placeholder="Category: p2p, uv, jeepney, bus, ejeep" required>
                <input type="text" name="transport" placeholder="Transport Type" required>
                <input type="text" name="operator" placeholder="Operator">
                <input type="text" name="origin" placeholder="Origin" required>
                <input type="text" name="destination" placeholder="Destination" required>
                <input type="number" step="0.01" name="fare" placeholder="Fare" required>
                <input type="text" name="travel_time" placeholder="Travel Time" required>
                <input type="text" name="distance" placeholder="Distance">
                <textarea name="schedule" placeholder="Schedule"></textarea>
                <input type="text" name="tag" placeholder="Tag">

                <select name="status">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>

                <button type="submit" class="btn btn-primary">Add Route</button>
            </form>
        </div>

        <div class="intelligence-surface">
            <h3>Existing Routes</h3>

            <?php while ($route = $routes->fetch_assoc()) { ?>
                <form action="save_route_admin.php" method="POST" style="border-bottom: 1px solid #ddd; padding: 16px 0;">
                    <input type="hidden" name="route_id" value="<?php echo $route['route_id']; ?>">

                    <input type="text" name="route_name" value="<?php echo htmlspecialchars($route['route_name']); ?>" required>
                    <input type="text" name="category" value="<?php echo htmlspecialchars($route['category']); ?>" required>
                    <input type="text" name="transport" value="<?php echo htmlspecialchars($route['transport']); ?>" required>
                    <input type="text" name="operator" value="<?php echo htmlspecialchars($route['operator']); ?>">
                    <input type="text" name="origin" value="<?php echo htmlspecialchars($route['origin']); ?>" required>
                    <input type="text" name="destination" value="<?php echo htmlspecialchars($route['destination']); ?>" required>
                    <input type="number" step="0.01" name="fare" value="<?php echo htmlspecialchars($route['fare']); ?>" required>
                    <input type="text" name="travel_time" value="<?php echo htmlspecialchars($route['travel_time']); ?>" required>
                    <input type="text" name="distance" value="<?php echo htmlspecialchars($route['distance']); ?>">
                    <textarea name="schedule"><?php echo htmlspecialchars($route['schedule']); ?></textarea>
                    <input type="text" name="tag" value="<?php echo htmlspecialchars($route['tag']); ?>">

                    <select name="status">
                        <option value="active" <?php if ($route['status'] === 'active') echo 'selected'; ?>>Active</option>
                        <option value="inactive" <?php if ($route['status'] === 'inactive') echo 'selected'; ?>>Inactive</option>
                    </select>

                    <button type="submit" class="btn btn-primary">Save Changes</button>

                    <a 
                        href="delete_route_admin.php?id=<?php echo $route['route_id']; ?>" 
                        class="btn btn-secondary"
                        onclick="return confirm('Delete this route?');">
                        Delete
                    </a>
                </form>
            <?php } ?>
        </div>

        <br>
        <a href="admin.php" class="btn btn-secondary">Back to Admin Dashboard</a>

    </main>
</div>

</body>
</html>