<?php
session_start();
header("Content-Type: application/json");

include "db.php";

if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        "status" => "error",
        "message" => "User not logged in"
    ]);
    exit();
}

$user_id = intval($_SESSION['user_id']);
$route_name = trim($_POST['route_name'] ?? '');
$origin = trim($_POST['origin'] ?? '');
$destination = trim($_POST['destination'] ?? '');
$transport = trim($_POST['transport'] ?? '');
$fare = trim($_POST['fare'] ?? '');
$travel_time = trim($_POST['travel_time'] ?? '');

if ($route_name === '' || $origin === '' || $destination === '' || $transport === '' || $fare === '' || $travel_time === '') {
    echo json_encode([
        "status" => "error",
        "message" => "Please complete all route details"
    ]);
    exit();
}

$fare_value = floatval($fare);

$check = $conn->prepare("SELECT saved_id FROM saved_routes WHERE user_id = ? AND route_name = ? AND origin = ? AND destination = ? AND transport = ? LIMIT 1");

if (!$check) {
    echo json_encode([
        "status" => "error",
        "message" => "Duplicate check failed: " . $conn->error
    ]);
    exit();
}

$check->bind_param("issss", $user_id, $route_name, $origin, $destination, $transport);
$check->execute();
$existing = $check->get_result();

if ($existing->num_rows > 0) {
    echo json_encode([
        "status" => "exists",
        "message" => "This route is already saved."
    ]);
    exit();
}

$stmt = $conn->prepare("INSERT INTO saved_routes (user_id, route_name, origin, destination, transport, fare, travel_time) VALUES (?, ?, ?, ?, ?, ?, ?)");

if (!$stmt) {
    echo json_encode([
        "status" => "error",
        "message" => "Save prepare failed: " . $conn->error
    ]);
    exit();
}

$stmt->bind_param("issssds", $user_id, $route_name, $origin, $destination, $transport, $fare_value, $travel_time);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "Route saved successfully"
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Failed to save route"
    ]);
}

$stmt->close();
$check->close();
$conn->close();
?>
