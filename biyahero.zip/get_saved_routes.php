<?php
session_start();
include "db.php";

header("Content-Type: application/json");

if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        "status" => "error",
        "message" => "User not logged in"
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT 
        saved_id,
        route_name,
        origin,
        destination,
        transport,
        fare,
        travel_time,
        saved_at
    FROM saved_routes
    WHERE user_id = ?
    ORDER BY saved_at DESC
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

$routes = [];

while ($row = $result->fetch_assoc()) {
    $routes[] = $row;
}

echo json_encode([
    "status" => "success",
    "routes" => $routes
]);

$stmt->close();
$conn->close();
?>