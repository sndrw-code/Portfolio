<?php
include "db.php";
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid request method."
    ]);
    exit();
}

$full_name = trim($_POST["full_name"] ?? "");
$age = trim($_POST["age"] ?? "");
$username = trim($_POST["username"] ?? "");
$password = $_POST["password"] ?? "";

if ($full_name === "" || $age === "" || $username === "" || $password === "") {
    echo json_encode([
        "status" => "empty",
        "message" => "Please complete all fields."
    ]);
    exit();
}

if (!is_numeric($age)) {
    echo json_encode([
        "status" => "invalid_age",
        "message" => "Age must be a valid number."
    ]);
    exit();
}

$check = $conn->prepare("SELECT user_id FROM users WHERE username = ? LIMIT 1");

if (!$check) {
    echo json_encode([
        "status" => "error",
        "message" => "Database query failed: " . $conn->error
    ]);
    exit();
}

$check->bind_param("s", $username);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    echo json_encode([
        "status" => "duplicate",
        "message" => "Username already exists."
    ]);
    exit();
}

$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$role = "commuter";
$age_value = intval($age);

$stmt = $conn->prepare("INSERT INTO users (full_name, age, username, password, role) VALUES (?, ?, ?, ?, ?)");

if (!$stmt) {
    echo json_encode([
        "status" => "error",
        "message" => "Database insert failed: " . $conn->error
    ]);
    exit();
}

$stmt->bind_param("sisss", $full_name, $age_value, $username, $hashed_password, $role);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "Account created successfully."
    ]);
    exit();
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Registration failed."
    ]);
    exit();
}
?>
