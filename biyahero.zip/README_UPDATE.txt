BiyaHero updated files

Included improvements:
1. Routes are loaded from MySQL through get_routes.php.
2. Admin add/edit/delete route now saves to the routes table through PHP.
3. Offline Access UI and JS logic were removed.
4. Admin command bar styling and logout reset were fixed.
5. Global topbar search now filters database routes.
6. register.php now uses prepared statements.
7. Alert boxes were replaced with toast notifications.

Installation:
- Copy these files into your BiyaHero folder in htdocs/www.
- Make sure filenames are exactly index.html, script.js, styles.css, etc.
- Import biyahero_db.sql in phpMyAdmin if your routes table is empty or outdated.
- Then hard refresh the browser with Ctrl + F5.
