<?php
session_start();
include "db.php";

$is_ajax = isset($_POST["ajax"]) || strtolower($_SERVER["HTTP_X_REQUESTED_WITH"] ?? "") === "xmlhttprequest";

function respondAdminDelete($status, $message) {
    global $is_ajax;

    if ($is_ajax) {
        header("Content-Type: application/json");
        echo json_encode([
            "status" => $status,
            "message" => $message
        ]);
    } else {
        if ($status === "success") {
            header("Location: admin.php");
        } else {
            echo $message;
        }
    }

    exit();
}

if (!isset($_SESSION["user_id"])) {
    respondAdminDelete("error", "User not logged in");
}

if ($_SESSION["role"] !== "admin" && $_SESSION["role"] !== "head_admin") {
    respondAdminDelete("error", "Access denied");
}

$route_id_raw = trim($_POST["route_id"] ?? $_POST["id"] ?? $_GET["id"] ?? "");
$route_id = ctype_digit($route_id_raw) ? intval($route_id_raw) : 0;

if ($route_id <= 0) {
    respondAdminDelete("error", "Missing route ID.");
}

$stmt = $conn->prepare("DELETE FROM routes WHERE route_id = ?");

if (!$stmt) {
    respondAdminDelete("error", "SQL prepare failed: " . $conn->error);
}

$stmt->bind_param("i", $route_id);

if ($stmt->execute()) {
    respondAdminDelete("success", "Route deleted successfully.");
}

respondAdminDelete("error", "Failed to delete route: " . $stmt->error);

$stmt->close();
$conn->close();
?>
