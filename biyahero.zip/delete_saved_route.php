<?php
session_start();
header("Content-Type: application/json");

include "db.php";

if (!isset($_SESSION["user_id"])) {
    echo json_encode([
        "status" => "error",
        "message" => "User not logged in"
    ]);
    exit();
}

if (!isset($_POST["saved_id"]) || empty($_POST["saved_id"])) {
    echo json_encode([
        "status" => "error",
        "message" => "Missing saved route ID"
    ]);
    exit();
}

$user_id = $_SESSION["user_id"];
$saved_id = intval($_POST["saved_id"]);

$stmt = $conn->prepare("DELETE FROM saved_routes WHERE saved_id = ? AND user_id = ?");

if (!$stmt) {
    echo json_encode([
        "status" => "error",
        "message" => "SQL prepare failed: " . $conn->error
    ]);
    exit();
}

$stmt->bind_param("ii", $saved_id, $user_id);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "Saved route removed successfully"
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Delete failed: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();
?>